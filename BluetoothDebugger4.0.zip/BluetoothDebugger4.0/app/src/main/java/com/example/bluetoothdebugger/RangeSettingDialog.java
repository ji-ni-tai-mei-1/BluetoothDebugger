package com.example.bluetoothdebugger;

import java.io.Serializable;

public class RangeSettingDialog {
    public static class Settings implements Serializable {
        private static final long serialVersionUID = 1L;

        public int joy1XMin, joy1XMax;
        public int joy1YMin, joy1YMax;
        public int joy2XMin, joy2XMax;
        public int joy2YMin, joy2YMax;
        public int seekMin, seekMax;
        public DataType joy1XType, joy1YType;
        public DataType joy2XType, joy2YType;
        public DataType seekType;

        public Settings() {
            joy1XMin = -90; joy1XMax = 90;
            joy1YMin = -90; joy1YMax = 90;
            joy2XMin = -90; joy2XMax = 90;
            joy2YMin = -90; joy2YMax = 90;
            seekMin = 0; seekMax = 100;
            joy1XType = DataType.INT8;
            joy1YType = DataType.INT8;
            joy2XType = DataType.INT8;
            joy2YType = DataType.INT8;
            seekType = DataType.UINT8;
        }
    }
}