package com.example.bluetoothdebugger;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;

/**
 * 选中/旋转模式的透明手势层。
 * 覆盖在控件画布之上并消费全部触摸，使下层控件在布局模式下不响应操作。
 * 手势：
 *  - 单击控件：选中（点空白取消选中）
 *  - 长按控件并拖动：移动控件
 *  - 双指：旋转控件，同时双指开合缩放控件
 */
public class ControlTransformOverlay extends View {

    public interface Listener {
        ControlItem hitTest(float x, float y);
        ControlItem getSelected();
        float getCenterX(ControlItem item);
        float getCenterY(ControlItem item);
        void onTap(ControlItem item);                    // item 为 null 表示点空白
        void onMoveTo(ControlItem item, float cx, float cy);
        void onRotateTo(ControlItem item, float angleDeg);
        void onScaleTo(ControlItem item, float scale);   // 双指缩放
    }

    private static final long LONG_PRESS_MS = 350L;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable longPressRunnable = this::onLongPress;

    private Listener listener;
    private int touchSlop;

    private float downX, downY;
    private ControlItem touchItem;
    private boolean longPressed = false;
    private boolean moved = false;
    private float moveBaseX, moveBaseY;

    private boolean rotating = false;
    private ControlItem rotateItem;
    private float rotateItemBase;
    private float rotateBaseAngle;
    private float rotateBaseScale;
    private float rotateBaseDist;

    public ControlTransformOverlay(Context context) {
        super(context);
        init(context);
    }

    public ControlTransformOverlay(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    public ControlTransformOverlay(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context);
    }

    private void init(Context context) {
        touchSlop = ViewConfiguration.get(context).getScaledTouchSlop();
        setClickable(true);
        setFocusable(true);
    }

    public void setListener(Listener listener) {
        this.listener = listener;
    }

    private void onLongPress() {
        if (listener == null || touchItem == null || rotating) return;
        longPressed = true;
        moveBaseX = listener.getCenterX(touchItem);
        moveBaseY = listener.getCenterY(touchItem);
        // 长按视为也要选中该控件
        listener.onTap(touchItem);
    }

    private float angleDeg(float ax, float ay, float bx, float by) {
        return (float) Math.toDegrees(Math.atan2(by - ay, bx - ax));
    }

    private float dist(float ax, float ay, float bx, float by) {
        float dx = bx - ax;
        float dy = by - ay;
        return (float) Math.sqrt(dx * dx + dy * dy);
    }

    @Override
    public boolean onTouchEvent(MotionEvent ev) {
        switch (ev.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downX = ev.getX();
                downY = ev.getY();
                touchItem = listener != null ? listener.hitTest(downX, downY) : null;
                longPressed = false;
                moved = false;
                rotating = false;
                rotateItem = null;
                handler.removeCallbacks(longPressRunnable);
                handler.postDelayed(longPressRunnable, LONG_PRESS_MS);
                return true;

            case MotionEvent.ACTION_POINTER_DOWN:
                handler.removeCallbacks(longPressRunnable);
                if (ev.getPointerCount() == 2 && !rotating) {
                    ControlItem target = touchItem;
                    if (target == null && listener != null) {
                        target = listener.getSelected();
                    }
                    if (target != null) {
                        rotating = true;
                        rotateItem = target;
                        rotateItemBase = target.angle;
                        rotateBaseScale = target.scale;
                        rotateBaseAngle = angleDeg(ev.getX(0), ev.getY(0), ev.getX(1), ev.getY(1));
                        rotateBaseDist = dist(ev.getX(0), ev.getY(0), ev.getX(1), ev.getY(1));
                        if (listener != null) listener.onTap(target);
                    }
                }
                return true;

            case MotionEvent.ACTION_MOVE:
                if (rotating && ev.getPointerCount() >= 2) {
                    float cur = angleDeg(ev.getX(0), ev.getY(0), ev.getX(1), ev.getY(1));
                    float d = dist(ev.getX(0), ev.getY(0), ev.getX(1), ev.getY(1));
                    if (listener != null && rotateItem != null) {
                        listener.onRotateTo(rotateItem, rotateItemBase + (cur - rotateBaseAngle));
                        if (rotateBaseDist > 0f) {
                            listener.onScaleTo(rotateItem, rotateBaseScale * (d / rotateBaseDist));
                        }
                    }
                    return true;
                }
                if (longPressed && touchItem != null) {
                    if (listener != null) {
                        float cx = moveBaseX + (ev.getX() - downX);
                        float cy = moveBaseY + (ev.getY() - downY);
                        listener.onMoveTo(touchItem, cx, cy);
                    }
                    return true;
                }
                float mx = ev.getX() - downX;
                float my = ev.getY() - downY;
                if (mx * mx + my * my > touchSlop * touchSlop) {
                    moved = true;
                    handler.removeCallbacks(longPressRunnable);
                }
                return true;

            case MotionEvent.ACTION_POINTER_UP:
                if (ev.getPointerCount() == 2) {
                    rotating = false;
                    rotateItem = null;
                }
                return true;

            case MotionEvent.ACTION_UP:
                handler.removeCallbacks(longPressRunnable);
                if (rotating) {
                    rotating = false;
                    rotateItem = null;
                    return true;
                }
                if (!moved && !longPressed && listener != null) {
                    listener.onTap(touchItem);
                }
                reset();
                return true;

            case MotionEvent.ACTION_CANCEL:
                reset();
                return true;
        }
        return true;
    }

    private void reset() {
        handler.removeCallbacks(longPressRunnable);
        longPressed = false;
        moved = false;
        rotating = false;
        rotateItem = null;
        touchItem = null;
    }
}
