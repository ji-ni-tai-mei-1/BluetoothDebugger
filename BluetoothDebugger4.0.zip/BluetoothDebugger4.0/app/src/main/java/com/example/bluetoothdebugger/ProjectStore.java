package com.example.bluetoothdebugger;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * 工程视图存储：每个工程包含 名称、横/竖屏、包头包尾、控件列表。
 * 数据以 JSON 数组保存在 SharedPreferences，供首页与调试界面读写。
 */
public class ProjectStore {

    public static class Project {
        public String name;
        public boolean landscape = true;   // true=横屏
        public byte[] header = new byte[]{(byte) 0xA5};
        public byte[] tail = new byte[]{(byte) 0x5A};
        public final List<ControlItem> items = new ArrayList<>();

        public Project(String name, boolean landscape) {
            this.name = name;
            this.landscape = landscape;
        }
    }

    private static final String PREFS = "proj_store";
    private static final String KEY = "projects_json";

    // 旧版(1.8/1.8.1)单布局键，用于首次升级时迁移
    private static final String OLD_PREFS = "ctrl_layout";
    private static final String OLD_KEY = "layout_json";

    private ProjectStore() {
    }

    public static List<Project> loadAll(Context ctx) {
        SharedPreferences sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String json = sp.getString(KEY, null);
        List<Project> list = new ArrayList<>();
        if (json == null) {
            // 首次启动：若存在旧版单布局则迁移成"默认工程(横屏)"，否则新建默认工程
            Project p = migrateOld(ctx);
            list.add(p);
            saveAll(ctx, list);
            return list;
        }
        try {
            JSONArray arr = new JSONArray(json);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                Project p = new Project(o.optString("name", "工程" + (i + 1)),
                        o.optBoolean("landscape", true));
                byte[] h = bytesFromJson(o.optJSONArray("header"));
                byte[] t = bytesFromJson(o.optJSONArray("tail"));
                if (h != null) p.header = h;
                if (t != null) p.tail = t;
                JSONArray cs = o.optJSONArray("controls");
                for (int j = 0; j < cs.length(); j++) {
                    p.items.add(ControlItem.fromJson(cs.getJSONObject(j)));
                }
                list.add(p);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (list.isEmpty()) {
            list.add(migrateOld(ctx));
        }
        return list;
    }

    public static Project get(Context ctx, String name) {
        for (Project p : loadAll(ctx)) {
            if (p.name.equals(name)) return p;
        }
        return null;
    }

    public static void save(Context ctx, Project project) {
        List<Project> all = loadAll(ctx);
        boolean found = false;
        for (int i = 0; i < all.size(); i++) {
            if (all.get(i).name.equals(project.name)) {
                all.set(i, project);
                found = true;
                break;
            }
        }
        if (!found) all.add(project);
        saveAll(ctx, all);
    }

    public static void delete(Context ctx, String name) {
        List<Project> all = loadAll(ctx);
        for (int i = all.size() - 1; i >= 0; i--) {
            if (all.get(i).name.equals(name)) all.remove(i);
        }
        saveAll(ctx, all);
    }

    private static void saveAll(Context ctx, List<Project> list) {
        SharedPreferences sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        try {
            JSONArray arr = new JSONArray();
            for (Project p : list) {
                JSONObject o = new JSONObject();
                o.put("name", p.name);
                o.put("landscape", p.landscape);
                o.put("header", bytesToJson(p.header));
                o.put("tail", bytesToJson(p.tail));
                JSONArray cs = new JSONArray();
                for (ControlItem it : p.items) cs.put(it.toJson());
                o.put("controls", cs);
                arr.put(o);
            }
            sp.edit().putString(KEY, arr.toString()).apply();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /** 首次使用：优先迁移旧版 1.8 的单布局，否则创建默认工程（横屏+默认控件） */
    private static Project migrateOld(Context ctx) {
        Project p = new Project("默认工程", true);
        SharedPreferences old = ctx.getSharedPreferences(OLD_PREFS, Context.MODE_PRIVATE);
        String json = old.getString(OLD_KEY, null);
        if (json != null) {
            try {
                JSONObject root = new JSONObject(json);
                byte[] h = bytesFromJson(root.optJSONArray("header"));
                byte[] t = bytesFromJson(root.optJSONArray("tail"));
                if (h != null) p.header = h;
                if (t != null) p.tail = t;
                JSONArray cs = root.optJSONArray("controls");
                for (int i = 0; i < cs.length(); i++) {
                    p.items.add(ControlItem.fromJson(cs.getJSONObject(i)));
                }
                old.edit().remove(OLD_KEY).apply();
                return p;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        addDefaultItems(p);
        return p;
    }

    private static void addDefaultItems(Project p) {
        ControlItem j1 = new ControlItem(ControlItem.Type.JOYSTICK, "摇杆1");
        j1.fx = 0.16; j1.fy = 0.82;
        ControlItem j2 = new ControlItem(ControlItem.Type.JOYSTICK, "摇杆2");
        j2.fx = 0.84; j2.fy = 0.82;
        ControlItem s = new ControlItem(ControlItem.Type.SLIDER, "滑杆1");
        s.fx = 0.5; s.fy = 0.30;
        ControlItem sw = new ControlItem(ControlItem.Type.SWITCH, "开关1");
        sw.fx = 0.5; sw.fy = 0.45;
        p.items.add(j1);
        p.items.add(j2);
        p.items.add(s);
        p.items.add(sw);
    }

    /** 创建新工程时的默认控件（按方向调整摆放，避免压住功能键） */
    public static void addNewProjectItems(Project p) {
        if (p.landscape) {
            addDefaultItems(p);
        } else {
            ControlItem j1 = new ControlItem(ControlItem.Type.JOYSTICK, "摇杆1");
            j1.fx = 0.22; j1.fy = 0.70;
            ControlItem j2 = new ControlItem(ControlItem.Type.JOYSTICK, "摇杆2");
            j2.fx = 0.78; j2.fy = 0.70;
            ControlItem s = new ControlItem(ControlItem.Type.SLIDER, "滑杆1");
            s.fx = 0.5; s.fy = 0.42;
            ControlItem sw = new ControlItem(ControlItem.Type.SWITCH, "开关1");
            sw.fx = 0.5; sw.fy = 0.55;
            p.items.add(j1);
            p.items.add(j2);
            p.items.add(s);
            p.items.add(sw);
        }
    }

    private static JSONArray bytesToJson(byte[] bytes) {
        JSONArray a = new JSONArray();
        for (byte b : bytes) a.put(b & 0xFF);
        return a;
    }

    private static byte[] bytesFromJson(JSONArray arr) {
        if (arr == null) return null;
        byte[] out = new byte[arr.length()];
        for (int i = 0; i < arr.length(); i++) out[i] = (byte) arr.optInt(i, 0);
        return out;
    }
}
