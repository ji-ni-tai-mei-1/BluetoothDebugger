package com.example.bluetoothdebugger;

import android.app.AlertDialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;

public class ControlSettingDialog {
    public interface OnSettingSavedListener {
        void onSaved(int min, int max, DataType type);
    }

    public static void show(Context context, String title, int currentMin, int currentMax, DataType currentType,
                            OnSettingSavedListener listener) {
        if (context == null || listener == null) return;
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        View view = LayoutInflater.from(context).inflate(R.layout.dialog_control_setting, null);
        builder.setView(view);
        builder.setTitle(title);

        EditText etMin = view.findViewById(R.id.etMin);
        EditText etMax = view.findViewById(R.id.etMax);
        Spinner spinnerType = view.findViewById(R.id.spinnerType);

        etMin.setText(String.valueOf(currentMin));
        etMax.setText(String.valueOf(currentMax));

        ArrayAdapter<DataType> adapter = new ArrayAdapter<>(context, android.R.layout.simple_spinner_item, DataType.values());
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerType.setAdapter(adapter);
        spinnerType.setSelection(currentType.ordinal());

        builder.setPositiveButton("保存", (dialog, which) -> {
            try {
                int min = Integer.parseInt(etMin.getText().toString());
                int max = Integer.parseInt(etMax.getText().toString());
                DataType type = (DataType) spinnerType.getSelectedItem();
                listener.onSaved(min, max, type);
            } catch (NumberFormatException e) {
                // 输入无效，忽略
            }
        });
        builder.setNegativeButton("取消", null);
        builder.show();
    }
}