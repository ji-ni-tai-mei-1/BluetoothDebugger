package com.example.bluetoothdebugger;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.ViewConfiguration;
import android.widget.LinearLayout;

import androidx.annotation.Nullable;

/**
 * 可长按拖动的悬浮窗根布局。
 * 长按（约 300ms）后进入拖动模式，后续 MOVE 事件通过 {@link OnDragListener} 回调；
 * 快速滑动或点击不会触发拖动，因此不影响内部 TextView 的滚动和按钮的点击。
 */
public class FloatingDragLayout extends LinearLayout {

    public interface OnDragListener {
        void onDragStart();
        void onDragMove(float dx, float dy);
        void onDragEnd();
    }

    private static final long LONG_PRESS_MS = 300L;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable longPressRunnable = new Runnable() {
        @Override
        public void run() {
            longPressTriggered = true;
        }
    };

    private OnDragListener dragListener;
    private boolean longPressTriggered = false;
    private boolean dragStarted = false;
    private float downRawX, downRawY;
    private int touchSlop;

    public FloatingDragLayout(Context context) {
        super(context);
        init(context);
    }

    public FloatingDragLayout(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    public FloatingDragLayout(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context);
    }

    private void init(Context context) {
        touchSlop = ViewConfiguration.get(context).getScaledTouchSlop();
    }

    public void setOnDragListener(OnDragListener listener) {
        this.dragListener = listener;
    }

    @Override
    public boolean onInterceptTouchEvent(MotionEvent ev) {
        switch (ev.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downRawX = ev.getRawX();
                downRawY = ev.getRawY();
                longPressTriggered = false;
                dragStarted = false;
                handler.removeCallbacks(longPressRunnable);
                handler.postDelayed(longPressRunnable, LONG_PRESS_MS);
                return false;
            case MotionEvent.ACTION_MOVE:
                if (longPressTriggered) {
                    if (!dragStarted) {
                        dragStarted = true;
                        if (dragListener != null) dragListener.onDragStart();
                    }
                    return true;
                }
                // 长按前手指移动超过阈值，视为滚动/滑动，取消长按
                float dx = ev.getRawX() - downRawX;
                float dy = ev.getRawY() - downRawY;
                if (dx * dx + dy * dy > touchSlop * touchSlop) {
                    handler.removeCallbacks(longPressRunnable);
                }
                return false;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                handler.removeCallbacks(longPressRunnable);
                longPressTriggered = false;
                dragStarted = false;
                return false;
        }
        return super.onInterceptTouchEvent(ev);
    }

    @Override
    public boolean onTouchEvent(MotionEvent ev) {
        switch (ev.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                return true;
            case MotionEvent.ACTION_MOVE:
                if (dragListener != null) {
                    dragListener.onDragMove(ev.getRawX() - downRawX, ev.getRawY() - downRawY);
                }
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                handler.removeCallbacks(longPressRunnable);
                longPressTriggered = false;
                dragStarted = false;
                if (dragListener != null) dragListener.onDragEnd();
                return true;
        }
        return super.onTouchEvent(ev);
    }
}
