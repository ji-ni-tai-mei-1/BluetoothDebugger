package com.example.bluetoothdebugger;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

public class JoystickView extends View {
    private Paint bgPaint;
    private Paint stickPaint;
    private Paint axisPaint;
    private float centerX, centerY;
    private float radius;
    private float stickRadius;
    private float stickX, stickY;
    private float joyX = 0f, joyY = 0f;
    private boolean showAxis = false;
    private OnJoystickMoveListener listener;

    public interface OnJoystickMoveListener {
        void onMove(float x, float y);
    }

    public JoystickView(Context context) {
        super(context);
        init();
    }

    public JoystickView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    private void init() {
        bgPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        bgPaint.setColor(Color.LTGRAY);
        bgPaint.setStyle(Paint.Style.FILL);

        stickPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        stickPaint.setColor(Color.DKGRAY);
        stickPaint.setStyle(Paint.Style.FILL);

        axisPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        axisPaint.setColor(0x99FFEB3B);   // 半透明黄色坐标轴
        axisPaint.setStrokeWidth(2f);
    }

    /** 是否在摇杆中心绘制十字坐标轴（随控件旋转，便于观察方向） */
    public void setShowAxis(boolean show) {
        if (showAxis != show) {
            showAxis = show;
            invalidate();
        }
    }

    public boolean isShowAxis() {
        return showAxis;
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        centerX = w / 2f;
        centerY = h / 2f;
        radius = Math.min(w, h) / 2f;
        stickRadius = radius / 3f;
        stickX = centerX;
        stickY = centerY;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        canvas.drawCircle(centerX, centerY, radius, bgPaint);
        if (showAxis) {
            // 坐标轴画在摇杆杆下方，随 View 旋转而转动
            float margin = radius * 0.18f;
            canvas.drawLine(margin, centerY, getWidth() - margin, centerY, axisPaint);
            canvas.drawLine(centerX, margin, centerX, getHeight() - margin, axisPaint);
        }
        canvas.drawCircle(stickX, stickY, stickRadius, stickPaint);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
            case MotionEvent.ACTION_MOVE:
                float touchX = event.getX();
                float touchY = event.getY();
                float dx = touchX - centerX;
                float dy = touchY - centerY;
                float distance = (float) Math.sqrt(dx * dx + dy * dy);
                if (distance < radius) {
                    stickX = touchX;
                    stickY = touchY;
                } else {
                    stickX = centerX + dx * radius / distance;
                    stickY = centerY + dy * radius / distance;
                }
                joyX = (stickX - centerX) / radius;
                joyY = (stickY - centerY) / radius;
                if (joyX > 1f) joyX = 1f;
                if (joyX < -1f) joyX = -1f;
                if (joyY > 1f) joyY = 1f;
                if (joyY < -1f) joyY = -1f;
                if (listener != null) {
                    listener.onMove(joyX, joyY);
                }
                invalidate();
                break;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                stickX = centerX;
                stickY = centerY;
                joyX = 0f;
                joyY = 0f;
                if (listener != null) {
                    listener.onMove(0f, 0f);
                }
                invalidate();
                break;
        }
        return true;
    }

    public void setOnJoystickMoveListener(OnJoystickMoveListener listener) {
        this.listener = listener;
    }

    public float getJoystickX() {
        return joyX;
    }

    public float getJoystickY() {
        return joyY;
    }
}