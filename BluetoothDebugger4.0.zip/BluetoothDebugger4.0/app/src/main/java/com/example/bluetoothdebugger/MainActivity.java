package com.example.bluetoothdebugger;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.method.ScrollingMovementMethod;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    private static final int REQUEST_ENABLE_BT = 1;
    private static final int REQUEST_SELECT_DEVICE = 2;
    private static final int PERMISSION_REQUEST_CODE = 100;
    private static final int REQUEST_OVERLAY_PERMISSION = 1000;

    // 连接按钮状态：未连接红 / 连接中蓝 / 连接成功绿
    private static final int STATE_DISCONNECTED = 0;
    private static final int STATE_CONNECTING = 1;
    private static final int STATE_CONNECTED = 2;

    // UI
    private FrameLayout surface;
    private TextView tvStatus, tvTx, tvRx, tvRate, tvVersion;
    private Button btnConnect;
    private Button btnRange, btnRotate, btnAddControl, btnHeaderTail, btnMjpeg;

    // 图传配置（保存于手机，全局生效）
    private MjpegView mjpegView;
    private static final String V_PREFS = "video_cfg";
    private static final String V_URL = "mjpeg_url";
    private static final String V_W = "mjpeg_w";    // 0=铺满
    private static final String V_H = "mjpeg_h";
    private static final String V_ZOOM = "mjpeg_zoom"; // 百分比
    private static final String V_ROT = "mjpeg_rot";
    private static final String DEFAULT_MJPEG_URL = "http://10.88.35.105:81/stream";
    private String mjpegUrl = "";
    private int mjpegW = 0, mjpegH = 0;
    private int mjpegZoom = 100;
    private int mjpegRot = 0;

    private BluetoothService bluetoothService;
    private BluetoothAdapter bluetoothAdapter;

    // ---------- 动态控件模型 ----------
    private final List<ControlItem> items = new ArrayList<>();
    private final List<ControlWidget> widgets = new ArrayList<>();
    private ControlItem selectedItem;
    private boolean rotateMode = false;
    private ControlTransformOverlay overlay;

    // 包头/包尾
    private byte[] headerBytes = new byte[]{(byte) 0xA5};
    private byte[] tailBytes = new byte[]{(byte) 0x5A};

    // 当前打开的工程（首页传入工程名；横/竖屏在创建工程时已定死）
    public static final String EXTRA_PROJECT = "project";
    private ProjectStore.Project project;
    private boolean landscapeUi;

    // 发送调度：9600bps ≈ 960 B/s，按包长动态计算发送间隔（至少 15ms）
    private Handler mainHandler = new Handler(Looper.getMainLooper());
    private Runnable rateUpdater;
    private long nextSendTime = 0;
    private boolean sendPending = false;
    private final Runnable pendingSend = this::firePendingSend;

    // ---------- 悬浮窗 ----------
    private WindowManager windowManager;
    private View floatingView;
    private TextView tvFloatingData;
    private Button btnCollapse, btnFloatToggle;
    private LinearLayout floatingTitleBar;
    private Button btnExpandFromCollapsed;
    private WindowManager.LayoutParams floatingParams;
    private List<String> receivedMessages = new ArrayList<>();
    private static final int MAX_MESSAGES = 100;
    private final SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm:ss", Locale.getDefault());

    private enum FloatState { EXPANDED, COLLAPSED, FULLSCREEN }
    private FloatState currentState = FloatState.EXPANDED;
    private int expandedWidth, expandedHeight;
    private int collapsedSize;
    private int fullscreenWidth, fullscreenHeight;
    private int joyDiameter;
    private int originalX, originalY;

    private float collapsedDragStartX, collapsedDragStartY;
    private int collapsedStartPosX, collapsedStartPosY;
    private boolean isCollapsedDragging = false;
    private boolean hasMovedInCollapsed = false;

    // =====================================================================
    // 生命周期
    // =====================================================================
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // 读取并锁定工程方向：创建工程时选定横/竖屏后，调试界面不允许再切换
        String projectName = getIntent().getStringExtra(EXTRA_PROJECT);
        project = ProjectStore.get(this, projectName != null ? projectName : "默认工程");
        if (project == null) {
            Toast.makeText(this, "找不到工程: " + projectName, Toast.LENGTH_SHORT).show();
            finish();
            return;
        }
        setRequestedOrientation(project.landscape
                ? android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
                : android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        landscapeUi = project.landscape;

        setContentView(R.layout.activity_main);

        applyFullscreen();

        initViews();
        buildChrome();

        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        if (bluetoothAdapter == null) {
            Toast.makeText(this, "设备不支持蓝牙", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        bluetoothService = BluetoothService.getInstance();
        bluetoothService.setConnectionListener(new BluetoothService.ConnectionListener() {
            @Override
            public void onConnected() {
                runOnUiThread(() -> {
                    nextSendTime = 0;   // 连接建立后让第一帧立即发送
                    setConnectUi(STATE_CONNECTED);
                });
            }

            @Override
            public void onDisconnected() {
                runOnUiThread(() -> setConnectUi(STATE_DISCONNECTED));
            }

            @Override
            public void onConnectionFailed(String reason) {
                runOnUiThread(() -> {
                    Toast.makeText(MainActivity.this, "连接失败: " + reason, Toast.LENGTH_SHORT).show();
                    setConnectUi(STATE_DISCONNECTED);
                });
            }

            @Override
            public void onDataReceived(byte[] data) {
                updateFloatingData(data);
            }
        });

        if (bluetoothService.isConnected()) {
            nextSendTime = 0;
            setConnectUi(STATE_CONNECTED);
        }

        checkPermissionsAndEnableBluetooth();
        setupClickListeners();

        // 加载本工程的包头包尾与控件
        headerBytes = project.header;
        tailBytes = project.tail;
        items.addAll(project.items);
        rebuildAllWidgets();

        // 图传：读取上次保存的网址与画面设置，自动开始播放
        loadVideoPrefs();
        applyMjpegSize();
        if (!mjpegUrl.isEmpty()) {
            startMjpeg();
        }

        rateUpdater = new Runnable() {
            @Override public void run() {
                bluetoothService.updateRate();
                tvTx.setText("TX: " + bluetoothService.getTotalTxBytes());
                tvRx.setText("RX: " + bluetoothService.getTotalRxBytes());
                tvRate.setText("速率: " + bluetoothService.getCurrentRate() + " B/s");
                mainHandler.postDelayed(this, 1000);
            }
        };
        mainHandler.post(rateUpdater);

        initFloatingWindow();
    }

    private void initViews() {
        surface = findViewById(R.id.surface);
        mjpegView = findViewById(R.id.mjpegView);
        tvStatus = findViewById(R.id.tvConnectionStatus);
        tvVersion = findViewById(R.id.tvVersion);
        tvVersion.setText("v" + BuildConfig.VERSION_NAME);
        tvTx = findViewById(R.id.tvTxBytes);
        tvRx = findViewById(R.id.tvRxBytes);
        tvRate = findViewById(R.id.tvRate);
        btnConnect = findViewById(R.id.btnConnect);
        setConnectUi(STATE_DISCONNECTED);
    }

    /** 连接按钮/状态 三色 UI：未连接=红，连接中=蓝，已连接=绿（圆角胶囊） */
    private void setConnectUi(int state) {
        if (btnConnect == null) return;
        btnConnect.setTextColor(Color.WHITE);
        btnConnect.setAllCaps(false);
        switch (state) {
            case STATE_CONNECTED:
                btnConnect.setBackground(roundRadius(Color.rgb(67, 180, 96), 14));
                btnConnect.setText("已连接");
                tvStatus.setText("已连接");
                tvStatus.setTextColor(ContextCompat.getColor(this, android.R.color.holo_green_dark));
                break;
            case STATE_CONNECTING:
                btnConnect.setBackground(roundRadius(Color.rgb(33, 150, 243), 14));
                btnConnect.setText("连接中…");
                tvStatus.setText("连接中…");
                tvStatus.setTextColor(ContextCompat.getColor(this, android.R.color.holo_blue_dark));
                break;
            default:
                btnConnect.setBackground(roundRadius(Color.rgb(229, 57, 53), 14));
                btnConnect.setText("连接设备");
                tvStatus.setText("未连接");
                tvStatus.setTextColor(ContextCompat.getColor(this, android.R.color.holo_red_dark));
                break;
        }
    }

    // =====================================================================
    // 底部控制按钮栏：范围 / 旋转 / ＋控件 / 包头尾；右下角横竖屏切换
    // =====================================================================
    private void buildChrome() {
        FrameLayout root = (FrameLayout) findViewById(android.R.id.content);

        // 透明手势层（选中/旋转模式使用），平时隐藏
        overlay = new ControlTransformOverlay(this);
        overlay.setLayoutParams(new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        overlay.setVisibility(View.GONE);
        overlay.setListener(new ControlTransformOverlay.Listener() {
            @Override
            public ControlItem hitTest(float x, float y) {
                return hitTestControl(x, y);
            }

            @Override
            public ControlItem getSelected() {
                return selectedItem;
            }

            @Override
            public float getCenterX(ControlItem item) {
                ControlWidget w = widgetOf(item);
                return w == null ? 0 : w.root.getX() + w.root.getWidth() / 2f;
            }

            @Override
            public float getCenterY(ControlItem item) {
                ControlWidget w = widgetOf(item);
                return w == null ? 0 : w.root.getY() + w.root.getHeight() / 2f;
            }

            @Override
            public void onTap(ControlItem item) {
                setSelected(item);
            }

            @Override
            public void onMoveTo(ControlItem item, float cx, float cy) {
                ControlWidget w = widgetOf(item);
                if (w != null) setWidgetCenter(w, cx, cy);
            }

            @Override
            public void onRotateTo(ControlItem item, float angleDeg) {
                ControlWidget w = widgetOf(item);
                if (w == null) return;
                item.angle = angleDeg;
                w.root.setRotation(angleDeg);
            }

            @Override
            public void onScaleTo(ControlItem item, float scale) {
                ControlWidget w = widgetOf(item);
                if (w == null) return;
                // 面积最小为原始 1/4 => 线尺寸最小 0.5；放大不设上限
                if (scale < 0.5f) scale = 0.5f;
                item.scale = scale;
                w.root.setScaleX(scale);
                w.root.setScaleY(scale);
            }
        });
        root.addView(overlay);

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        FrameLayout.LayoutParams barLp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        if (landscapeUi) {
            // 横屏：固定右上角（默认布局，不修改）
            barLp.gravity = Gravity.TOP | Gravity.END;
            barLp.rightMargin = dp(8);
            barLp.topMargin = dp(8);
        } else {
            // 竖屏：四个功能键固定在屏幕最下方
            barLp.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
            barLp.bottomMargin = dp(10);
        }
        bar.setLayoutParams(barLp);

        btnRange = makeCapsule("范围", Color.argb(200, 200, 60, 50));
        btnRotate = makeCapsule("调节", Color.argb(190, 70, 120, 220));
        btnAddControl = makeCapsule("＋－控件", Color.argb(200, 40, 150, 90));
        btnHeaderTail = makeCapsule("包头尾", Color.argb(190, 110, 110, 110));
        btnMjpeg = makeCapsule("图传", Color.argb(200, 120, 80, 180));
        bar.addView(btnRange);
        bar.addView(btnRotate);
        bar.addView(btnAddControl);
        bar.addView(btnHeaderTail);
        bar.addView(btnMjpeg);
        root.addView(bar);

        btnRange.setOnClickListener(v -> onRangeClick());
        btnRotate.setOnClickListener(v -> toggleRotateMode());
        btnAddControl.setOnClickListener(v -> showControlManagerDialog());
        btnHeaderTail.setOnClickListener(v -> showHeaderTailDialog());
        btnMjpeg.setOnClickListener(v -> showMjpegMenu());
    }

    private Button makeCapsule(String text, int bgColor) {
        Button b = new Button(this);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, dp(34));
        lp.setMargins(0, 0, dp(4), 0);
        b.setLayoutParams(lp);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setTextSize(10);
        b.setAllCaps(false);
        b.setMinWidth(dp(48));
        b.setMinHeight(dp(34));
        b.setPadding(dp(8), 0, dp(8), 0);
        b.setBackground(roundRadius(bgColor, 12));
        return b;
    }

    private void setRotateButtonStyle(boolean active) {
        if (active) {
            btnRotate.setBackground(roundRadius(Color.argb(255, 255, 193, 7), 12));
            btnRotate.setTextColor(Color.BLACK);
        } else {
            btnRotate.setBackground(roundRadius(Color.argb(190, 70, 120, 220), 12));
            btnRotate.setTextColor(Color.WHITE);
        }
    }

    private GradientDrawable round(int color) {
        return roundRadius(color, 20);
    }

    /** 圆角矩形背景（radiusDp 为圆角半径） */
    private GradientDrawable roundRadius(int color, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.RECTANGLE);
        g.setCornerRadius(dp(radiusDp));
        g.setColor(color);
        return g;
    }

    // =====================================================================
    // 图传（ESP32-CAM 网页画面作为控件下层背景）
    // =====================================================================
    private void showMjpegMenu() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(8), dp(20), 0);

        // 网址输入 + 进入
        TextView tip = new TextView(this);
        tip.setText("图传网址（默认 " + DEFAULT_MJPEG_URL
                + "；请填完整地址，App 不做任何修改）");
        tip.setTextSize(13);
        tip.setTextColor(0xFF666666);
        box.addView(tip);
        final EditText etUrl = new EditText(this);
        etUrl.setText(mjpegUrl.isEmpty() ? DEFAULT_MJPEG_URL : mjpegUrl);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams etLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        etUrl.setLayoutParams(etLp);
        Button btnEnter = new Button(this);
        LinearLayout.LayoutParams enterLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        btnEnter.setLayoutParams(enterLp);
        btnEnter.setText("进入网址");
        btnEnter.setTextSize(12);
        btnEnter.setBackground(roundRadius(Color.argb(255, 90, 150, 220), 12));
        btnEnter.setTextColor(Color.WHITE);
        row.addView(etUrl);
        row.addView(btnEnter);
        box.addView(row);

        // 开始/停止图传 单键切换：默认"开始图传"，点击后变"停止图传"
        final Button btnToggle = new Button(this);
        LinearLayout.LayoutParams tgLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(44));
        tgLp.topMargin = dp(10);
        btnToggle.setLayoutParams(tgLp);
        btnToggle.setTextSize(14);
        btnToggle.setTextColor(Color.WHITE);
        refreshMjpegToggle(btnToggle);
        box.addView(btnToggle);

        // 画面调节入口（一个窗口内含：画面长/宽/缩放/方向 + 摄像头全部参数）
        final Button btnAdjust = new Button(this);
        LinearLayout.LayoutParams adjLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(42));
        adjLp.topMargin = dp(8);
        btnAdjust.setLayoutParams(adjLp);
        btnAdjust.setText("画面调节");
        btnAdjust.setTextSize(14);
        btnAdjust.setTextColor(Color.WHITE);
        btnAdjust.setBackground(roundRadius(Color.argb(255, 120, 80, 180), 12));
        box.addView(btnAdjust);

        // 添加/删除 LED 补光滑杆（0~255，固定不可改）
        final Button btnLed = new Button(this);
        LinearLayout.LayoutParams ledLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(42));
        ledLp.topMargin = dp(8);
        btnLed.setLayoutParams(ledLp);
        btnLed.setTextSize(14);
        btnLed.setTextColor(Color.WHITE);
        refreshLedButton(btnLed);
        box.addView(btnLed);

        final AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("图传")
                .setView(box)
                .setNegativeButton("关闭", null)
                .create();

        btnEnter.setOnClickListener(v -> {
            String u = etUrl.getText().toString().trim();
            if (u.isEmpty()) {
                Toast.makeText(this, "网址不能为空", Toast.LENGTH_SHORT).show();
                return;
            }
            mjpegUrl = u;
            saveVideoPrefs();
            // 输入新网址后立即重新进入（完全按用户输入连接）
            stopMjpeg();
            startMjpeg();
            refreshMjpegToggle(btnToggle);
            Toast.makeText(this, "已进入图传 " + mjpegUrl, Toast.LENGTH_SHORT).show();
        });

        btnToggle.setOnClickListener(v -> {
            if (mjpegView.isRunning()) {
                stopMjpeg();
            } else {
                startMjpeg();
            }
            refreshMjpegToggle(btnToggle);
        });

        btnAdjust.setOnClickListener(v -> {
            dialog.dismiss();
            showMjpegAdjustDialog();
        });

        btnLed.setOnClickListener(v -> {
            toggleLedSlider();
            refreshLedButton(btnLed);
        });

        dialog.show();
    }

    /** LED 滑杆添加/删除按钮文字 */
    private void refreshLedButton(Button btn) {
        if (btn == null) return;
        if (ledSliderExists()) {
            btn.setText("删除LED滑杆");
            btn.setBackground(roundRadius(Color.argb(255, 220, 60, 50), 12));
        } else {
            btn.setText("添加LED滑杆");
            btn.setBackground(roundRadius(Color.argb(255, 230, 150, 30), 12));
        }
    }

    private boolean ledSliderExists() {
        for (ControlItem it : items) {
            if (it.ledLight) return true;
        }
        return false;
    }

    /** 有则删除、无则添加一个 LED 补光滑杆（0~255 固定） */
    private void toggleLedSlider() {
        for (int i = items.size() - 1; i >= 0; i--) {
            if (items.get(i).ledLight) {
                removeWidgetAndItem(items.get(i));
                Toast.makeText(this, "已删除 LED 滑杆", Toast.LENGTH_SHORT).show();
                return;
            }
        }
        ControlItem it = new ControlItem(ControlItem.Type.SLIDER, "LED滑杆");
        it.ledLight = true;
        it.chVal.min = 0;
        it.chVal.max = 255;
        it.chVal.type = DataType.UINT8;
        items.add(it);
        addWidgetFor(it);
        saveState();
        Toast.makeText(this, "已添加 LED 滑杆（0~255）", Toast.LENGTH_SHORT).show();
    }

    private void removeWidgetAndItem(ControlItem item) {
        ControlWidget cw = widgetOf(item);
        if (cw != null) {
            surface.removeView(cw.root);
            widgets.remove(cw);
        }
        items.remove(item);
        if (selectedItem == item) selectedItem = null;
        saveState();
    }

    private void refreshMjpegToggle(Button btn) {
        if (btn == null) return;
        if (mjpegView.isRunning()) {
            btn.setText("停止图传");
            btn.setBackground(roundRadius(Color.argb(255, 220, 60, 50), 12));
        } else {
            btn.setText("开始图传");
            btn.setBackground(roundRadius(Color.argb(255, 67, 180, 96), 12));
        }
    }

    private void startMjpeg() {
        if (mjpegUrl.isEmpty()) return;
        mjpegView.start(mjpegUrl);
    }

    private void stopMjpeg() {
        mjpegView.stop();
    }

    private void showMjpegSizeDialog() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(8), dp(20), 0);

        box.addView(label("画面长（dp，0 = 铺满宽度）"));
        EditText etW = new EditText(this);
        etW.setText(String.valueOf(mjpegW));
        box.addView(etW);

        box.addView(label("画面宽（dp，0 = 铺满高度）"));
        EditText etH = new EditText(this);
        etH.setText(String.valueOf(mjpegH));
        box.addView(etH);

        box.addView(label("缩放（%，100 = 适应画面）"));
        EditText etZoom = new EditText(this);
        etZoom.setText(String.valueOf(mjpegZoom));
        box.addView(etZoom);

        box.addView(label("方向："));
        RadioGroup group = new RadioGroup(this);
        group.setOrientation(RadioGroup.HORIZONTAL);
        int[] rots = {0, 90, 180, 270};
        int[] ids = new int[rots.length];
        for (int i = 0; i < rots.length; i++) {
            RadioButton rb = new RadioButton(this);
            rb.setText(rots[i] + "°");
            ids[i] = View.generateViewId();
            rb.setId(ids[i]);
            group.addView(rb);
            if (mjpegRot == rots[i]) group.check(ids[i]);
        }
        if (group.getCheckedRadioButtonId() == View.NO_ID) group.check(ids[0]);
        box.addView(group);

        new AlertDialog.Builder(this)
                .setTitle("调整图传画面")
                .setView(box)
                .setPositiveButton("应用", (d, w) -> {
                    try {
                        mjpegW = Math.max(0, Integer.parseInt(etW.getText().toString().trim()));
                        mjpegH = Math.max(0, Integer.parseInt(etH.getText().toString().trim()));
                        mjpegZoom = Math.max(10, Math.min(400,
                                Integer.parseInt(etZoom.getText().toString().trim())));
                    } catch (NumberFormatException e) {
                        Toast.makeText(this, "请输入有效数字", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    for (int i = 0; i < ids.length; i++) {
                        if (group.getCheckedRadioButtonId() == ids[i]) {
                            mjpegRot = rots[i];
                            break;
                        }
                    }
                    saveVideoPrefs();
                    applyMjpegSize();
                    Toast.makeText(this, "画面设置已应用", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private TextView label(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(13);
        t.setTextColor(0xFF444444);
        t.setPadding(0, dp(8), 0, 0);
        return t;
    }

    private void loadVideoPrefs() {
        SharedPreferences sp = getSharedPreferences(V_PREFS, Context.MODE_PRIVATE);
        mjpegUrl = sp.getString(V_URL, "");
        mjpegW = sp.getInt(V_W, 0);
        mjpegH = sp.getInt(V_H, 0);
        mjpegZoom = sp.getInt(V_ZOOM, 100);
        mjpegRot = sp.getInt(V_ROT, 0);
    }

    private void saveVideoPrefs() {
        getSharedPreferences(V_PREFS, Context.MODE_PRIVATE)
                .edit()
                .putString(V_URL, mjpegUrl)
                .putInt(V_W, mjpegW)
                .putInt(V_H, mjpegH)
                .putInt(V_ZOOM, mjpegZoom)
                .putInt(V_ROT, mjpegRot)
                .apply();
    }

    private void applyMjpegSize() {
        if (mjpegView == null) return;
        FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) mjpegView.getLayoutParams();
        lp.width = mjpegW <= 0 ? FrameLayout.LayoutParams.MATCH_PARENT : dp(mjpegW);
        lp.height = mjpegH <= 0 ? FrameLayout.LayoutParams.MATCH_PARENT : dp(mjpegH);
        mjpegView.setLayoutParams(lp);
        mjpegView.setConfig(mjpegZoom / 100f, mjpegRot);
    }

    // =====================================================================
    // 视频参数面板：与网页端一致，通过 GET /control?var=xxx&val=yyy 下发
    // =====================================================================
    private static final String[][] RANGE_PARAMS = {
            // 默认值按截图设置：quality=4, brightness/contrast=3(-3~3), saturation=4(-4~4),
            // sharpness=3(-3~3), ae_level=5(-5~5), gainceiling=511(0~511), led=0
            {"quality", "画质", "4", "63", "4"},
            {"brightness", "亮度", "-3", "3", "3"},
            {"contrast", "对比度", "-3", "3", "3"},
            {"saturation", "饱和度", "-4", "4", "4"},
            {"sharpness", "锐度", "-3", "3", "3"},
            {"ae_level", "曝光级别", "-5", "5", "5"},
            {"gainceiling", "增益上限", "0", "511", "511"},
            {"led_intensity", "LED 补光", "0", "255", "0"},
    };

    private static final String[][] SPIN_PARAMS = {
            {"framesize", "分辨率", "0,1,2,3,4,5,6,8,9,10,11,12,13,14,15",
                    "96x96,160x120,176x144,240x176,240x240,320x240,640x480,400x296,480x320,800x600,1024x768,1280x720,1280x1024,1600x1200", "6"},
            {"special_effect", "特效", "0,1,2,3,4,5,6",
                    "无,负片,灰度,红色调,绿色调,蓝色调,复古", "0"},
            {"wb_mode", "白平衡", "0,1,2,3,4", "自动,晴,阴,办公室,家里", "0"},
    };

    private static final String[][] TOGGLE_PARAMS = {
            {"awb", "自动白平衡", "1"},
            {"awb_gain", "高级白平衡", "1"},
            {"aec", "自动曝光", "1"},
            {"agc", "自动增益", "1"},
            {"raw_gma", "Gamma 校正", "1"},
            {"lenc", "镜头校正", "1"},
            {"vflip", "垂直翻转", "1"},
            {"hmirror", "水平镜像", "0"},
    };

    /** 图传 → 画面调节：一个窗口内含 画面长/宽/缩放/方向 + 摄像头全部参数 */
    private void showMjpegAdjustDialog() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(4), dp(20), dp(4));
        scroll.addView(box, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView sec1 = new TextView(this);
        sec1.setText("— 画面显示设置 —");
        sec1.setTextSize(13);
        sec1.setTextColor(0xFF888888);
        sec1.setPadding(0, 0, 0, dp(4));
        box.addView(sec1);

        box.addView(label("画面长（dp，0=铺满宽度）"));
        final EditText etW = new EditText(this);
        etW.setText(String.valueOf(mjpegW));
        box.addView(etW);
        box.addView(label("画面宽（dp，0=铺满高度）"));
        final EditText etH = new EditText(this);
        etH.setText(String.valueOf(mjpegH));
        box.addView(etH);
        box.addView(label("画面缩放（%，100=适应）"));
        final EditText etZoom = new EditText(this);
        etZoom.setText(String.valueOf(mjpegZoom));
        box.addView(etZoom);
        box.addView(label("画面方向："));
        RadioGroup group = new RadioGroup(this);
        group.setOrientation(RadioGroup.HORIZONTAL);
        int[] rots = {0, 90, 180, 270};
        int[] ids = new int[rots.length];
        for (int i = 0; i < rots.length; i++) {
            RadioButton rb = new RadioButton(this);
            rb.setText(rots[i] + "°");
            ids[i] = View.generateViewId();
            rb.setId(ids[i]);
            group.addView(rb);
            if (mjpegRot == rots[i]) group.check(ids[i]);
        }
        if (group.getCheckedRadioButtonId() == View.NO_ID) group.check(ids[0]);
        box.addView(group);

        Button btnApply = new Button(this);
        LinearLayout.LayoutParams apLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, dp(38));
        apLp.topMargin = dp(4);
        btnApply.setLayoutParams(apLp);
        btnApply.setText("应用画面设置");
        btnApply.setTextSize(13);
        btnApply.setTextColor(Color.WHITE);
        btnApply.setBackground(roundRadius(Color.argb(255, 120, 80, 180), 12));
        btnApply.setOnClickListener(v -> {
            try {
                mjpegW = Math.max(0, Integer.parseInt(etW.getText().toString().trim()));
                mjpegH = Math.max(0, Integer.parseInt(etH.getText().toString().trim()));
                mjpegZoom = Math.max(10, Math.min(400,
                        Integer.parseInt(etZoom.getText().toString().trim())));
            } catch (NumberFormatException e) {
                Toast.makeText(this, "画面参数请输入有效数字", Toast.LENGTH_SHORT).show();
                return;
            }
            for (int i = 0; i < ids.length; i++) {
                if (group.getCheckedRadioButtonId() == ids[i]) {
                    mjpegRot = rots[i];
                    break;
                }
            }
            saveVideoPrefs();
            applyMjpegSize();
            Toast.makeText(this, "画面设置已应用", Toast.LENGTH_SHORT).show();
        });
        box.addView(btnApply);

        TextView sec2 = new TextView(this);
        sec2.setText("— 摄像头参数（拖动/选择即下发，默认见截图） —");
        sec2.setTextSize(13);
        sec2.setTextColor(0xFF888888);
        sec2.setPadding(0, dp(12), 0, 0);
        box.addView(sec2);

        for (String[] p : RANGE_PARAMS) {
            addParamSlider(box, p[0], p[1], Integer.parseInt(p[2]),
                    Integer.parseInt(p[3]), Integer.parseInt(p[4]));
        }
        for (String[] p : SPIN_PARAMS) {
            addParamSpinner(box, p[0], p[1], p[2], p[3], Integer.parseInt(p[4]));
        }
        for (String[] p : TOGGLE_PARAMS) {
            addParamCheck(box, p[0], p[1], "1".equals(p[2]));
        }

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("画面调节")
                .setView(scroll)
                .setNegativeButton("关闭", null)
                .create();
        dialog.show();
        // 背景全透明 + 去变暗，方便实时观察后面的图传画面调效果
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(
                    new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
            dialog.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
        }
    }

    private void addParamSlider(LinearLayout parent, final String var, String label,
                                final int min, final int max, final int def) {
        TextView tv = new TextView(this);
        tv.setText(label);
        tv.setTextSize(14);
        tv.setTextColor(0xFF333333);
        tv.setPadding(0, dp(10), 0, 0);
        parent.addView(tv);

        final TextView valTv = new TextView(this);
        valTv.setText(String.valueOf(def));
        valTv.setTextSize(12);
        valTv.setTextColor(0xFF0088CC);
        parent.addView(valTv);

        SeekBar sb = new SeekBar(this);
        sb.setMax(Math.max(max - min, 1));
        sb.setProgress(def - min);
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seek, int progress, boolean fromUser) {
                valTv.setText(String.valueOf(min + progress));
            }
            @Override public void onStartTrackingTouch(SeekBar seek) {}
            @Override public void onStopTrackingTouch(SeekBar seek) {
                sendCameraControl(var, min + seek.getProgress());
            }
        });
        parent.addView(sb);
    }

    private void addParamSpinner(LinearLayout parent, final String var, String label,
                                 String valuesCsv, String namesCsv, final int def) {
        TextView tv = new TextView(this);
        tv.setText(label);
        tv.setTextSize(14);
        tv.setTextColor(0xFF333333);
        tv.setPadding(0, dp(10), 0, 0);
        parent.addView(tv);

        String[] names = namesCsv.split(",");
        final String[] values = valuesCsv.split(",");
        Spinner sp = new Spinner(this);
        ArrayAdapter<String> ad = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, names);
        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sp.setAdapter(ad);
        for (int i = 0; i < values.length; i++) {
            if (Integer.parseInt(values[i]) == def) { sp.setSelection(i); break; }
        }
        sp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            private boolean first = true;
            @Override public void onItemSelected(AdapterView<?> p, View v, int pos, long id) {
                if (first) { first = false; return; }   // 忽略程序初始化触发
                sendCameraControl(var, Integer.parseInt(values[pos]));
            }
            @Override public void onNothingSelected(AdapterView<?> p) {}
        });
        parent.addView(sp);
    }

    private void addParamCheck(LinearLayout parent, final String var, String label, boolean initialOn) {
        android.widget.CheckBox cb = new android.widget.CheckBox(this);
        cb.setText(label);
        cb.setTextSize(14);
        cb.setChecked(initialOn);   // 初始化状态不发请求
        cb.setOnCheckedChangeListener((b, checked) ->
                sendCameraControl(var, checked ? 1 : 0));
        parent.addView(cb);
    }

    /** 下发一条摄像头参数：GET http://<主机>/control?var=..&val=.. */
    private void sendCameraControl(final String var, final int val) {
        final String base = controlBase();
        new Thread(() -> {
            try {
                HttpURLConnection c = (HttpURLConnection) new URL(
                        base + "/control?var=" + var + "&val=" + val).openConnection();
                c.setConnectTimeout(3000);
                c.setReadTimeout(3000);
                c.connect();
                c.getResponseCode();
                c.disconnect();
            } catch (Exception ignored) {
            }
        }).start();
    }

    /** 由图传网址推导 UI 控制服务地址（默认网页在 80 端口） */
    private String controlBase() {
        try {
            java.net.URL u = new java.net.URL(mjpegUrl.isEmpty() ? DEFAULT_MJPEG_URL : mjpegUrl);
            return u.getProtocol() + "://" + u.getHost();
        } catch (Exception e) {
            return "http://10.88.35.105";
        }
    }

    // =====================================================================
    // 控件添加 / 持久化
    // =====================================================================
    /**
     * ＋－控件：上方是三种添加类型；左下角红色"删除控件"胶囊。
     */
    private void showControlManagerDialog() {
        String[] options = {"添加：摇杆（X/Y 两通道）", "添加：滑杆", "添加：胶囊开关"};
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("添加 / 删除控件")
                .setItems(options, (d, which) -> {
                    ControlItem.Type type = which == 0 ? ControlItem.Type.JOYSTICK
                            : which == 1 ? ControlItem.Type.SLIDER : ControlItem.Type.SWITCH;
                    addControlOfType(type);
                })
                .setNegativeButton("删除控件", (d, w) -> showDeleteControlDialog())
                .setPositiveButton("关闭", null)
                .create();
        dialog.show();
        // 左下角红色胶囊背景的删除按钮
        dialog.getButton(AlertDialog.BUTTON_NEGATIVE)
                .setBackground(round(Color.argb(255, 220, 60, 50)));
        dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(Color.WHITE);
    }

    private void addControlOfType(ControlItem.Type type) {
        int n = 1;
        for (ControlItem it : items) if (it.type == type) n++;
        String prefix = type == ControlItem.Type.JOYSTICK ? "摇杆"
                : type == ControlItem.Type.SLIDER ? "滑杆" : "开关";
        ControlItem item = new ControlItem(type, prefix + n);
        item.fx = 0.5;
        item.fy = 0.5;
        items.add(item);
        addWidgetFor(item);
        saveState();
        Toast.makeText(this, "已添加 " + item.label + "（默认居中）", Toast.LENGTH_SHORT).show();
    }

    private void showDeleteControlDialog() {
        if (items.isEmpty()) {
            Toast.makeText(this, "没有可删除的控件", Toast.LENGTH_SHORT).show();
            return;
        }
        String[] labels = new String[items.size()];
        for (int i = 0; i < items.size(); i++) labels[i] = items.get(i).label;
        new AlertDialog.Builder(this)
                .setTitle("选择要删除的控件")
                .setItems(labels, (d, which) -> deleteItem(items.get(which)))
                .setNegativeButton("取消", null)
                .show();
    }

    private void showHeaderTailDialog() {
        View view = LayoutInflater.from(this).inflate(R.layout.dialog_header_tail, null);
        EditText etHeader = view.findViewById(R.id.etHeader);
        EditText etTail = view.findViewById(R.id.etTail);
        TextView tvPreview = view.findViewById(R.id.tvPacketPreview);
        etHeader.setText(bytesToHex(headerBytes).replace(" ", ""));
        etTail.setText(bytesToHex(tailBytes).replace(" ", ""));

        TextWatcher watcher = new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) {
                updatePacketPreview(tvPreview, etHeader, etTail);
            }
            @Override public void afterTextChanged(Editable s) {}
        };
        etHeader.addTextChangedListener(watcher);
        etTail.addTextChangedListener(watcher);
        updatePacketPreview(tvPreview, etHeader, etTail);

        new AlertDialog.Builder(this)
                .setTitle("设置包头 / 包尾")
                .setView(view)
                .setPositiveButton("保存", (d, w) -> {
                    byte[] h = parseHex(etHeader.getText().toString());
                    byte[] t = parseHex(etTail.getText().toString());
                    if (h == null || t == null) {
                        Toast.makeText(this, "格式错误：应为十六进制，如 A5 / 5A", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    headerBytes = h;
                    tailBytes = t;
                    saveState();
                    triggerSend();
                    Toast.makeText(this, "包头 " + bytesToHex(headerBytes) + " / 包尾 "
                            + bytesToHex(tailBytes), Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("取消", null)
                .show();
    }

    /** 实时预览数据包结构，元素之间用逗号分隔，如：0xA5,摇杆1X,摇杆1Y,滑杆1,开关1,0x5A */
    private void updatePacketPreview(TextView tv, EditText etHeader, EditText etTail) {
        if (tv == null) return;
        byte[] h = parseHex(etHeader.getText().toString());
        byte[] t = parseHex(etTail.getText().toString());
        if (h == null || t == null) {
            tv.setText("十六进制输入无效（应为偶数位，如 A5）");
            return;
        }
        List<String> parts = new ArrayList<>();
        for (byte b : h) parts.add(String.format("0x%02X", b));
        for (ControlItem it : items) {
            if (it.ledLight) continue;   // LED 滑杆不进蓝牙数据包
            if (it.type == ControlItem.Type.JOYSTICK) {
                parts.add(it.label + "X");
                parts.add(it.label + "Y");
            } else {
                parts.add(it.label);
            }
        }
        for (byte b : t) parts.add(String.format("0x%02X", b));

        // 计算包总字节数与建议发送间隔
        int bytes = h.length + t.length;
        for (ControlItem it : items) {
            if (it.ledLight) continue;   // LED 滑杆不进蓝牙数据包
            if (it.type == ControlItem.Type.JOYSTICK) {
                bytes += it.chX.type.getByteLength() + it.chY.type.getByteLength();
            } else if (it.type == ControlItem.Type.SLIDER) {
                bytes += it.chVal.type.getByteLength();
            } else {
                bytes += 1;
            }
        }
        tv.setText("结构：" + TextUtils.join(",", parts)
                + "\n包长 " + bytes + " 字节 · 9600bps 建议发送间隔 ≥ " + intervalForBytes(bytes) + "ms");
    }

    private byte[] parseHex(String s) {
        if (s == null) return new byte[0];
        String cleaned = s.replaceAll("[,\\s]+", "");
        if (cleaned.isEmpty()) return new byte[0];
        if (cleaned.length() % 2 != 0) return null;
        byte[] out = new byte[cleaned.length() / 2];
        try {
            for (int i = 0; i < out.length; i++) {
                out[i] = (byte) Integer.parseInt(cleaned.substring(i * 2, i * 2 + 2), 16);
            }
        } catch (NumberFormatException e) {
            return null;
        }
        return out;
    }

    /** 保存当前工程（包头包尾 + 控件列表）到工程库 */
    private void saveState() {
        project.items.clear();
        project.items.addAll(items);
        project.header = headerBytes;
        project.tail = tailBytes;
        ProjectStore.save(this, project);
    }

    @Override
    protected void onPause() {
        super.onPause();
        saveState();
    }

    // =====================================================================
    // 控件视图构建与摆放
    // =====================================================================
    private void rebuildAllWidgets() {
        surface.removeAllViews();
        widgets.clear();
        for (ControlItem item : items) {
            addWidgetFor(item);
        }
    }

    private void addWidgetFor(ControlItem item) {
        int wDp;
        if (item.type == ControlItem.Type.JOYSTICK) wDp = 150;
        else if (item.type == ControlItem.Type.SLIDER) wDp = 230;
        else wDp = 130;

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER_HORIZONTAL);
        box.setPadding(dp(6), dp(4), dp(6), dp(4));
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(dp(wDp), ViewGroup.LayoutParams.WRAP_CONTENT);
        box.setLayoutParams(lp);
        box.setBackground(makeBoxBackground(false));

        TextView title = new TextView(this);
        title.setText(item.label);
        title.setTextColor(Color.WHITE);
        title.setTextSize(12);
        title.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        title.setGravity(Gravity.CENTER);
        box.addView(title);

        ControlWidget widget = new ControlWidget(item, box, title);

        TextView value = new TextView(this);
        value.setTextColor(0xDDFFFFFF);
        value.setTextSize(11);
        value.setGravity(Gravity.CENTER);

        if (item.type == ControlItem.Type.JOYSTICK) {
            JoystickView joy = new JoystickView(this);
            LinearLayout.LayoutParams jp = new LinearLayout.LayoutParams(dp(110), dp(110));
            joy.setLayoutParams(jp);
            joy.setOnJoystickMoveListener((x, y) -> {
                widget.joyX = x;
                widget.joyY = y;
                refreshWidgetValue(widget);
                if (x == 0f && y == 0f) {
                    // 松开/归零：绕过节流立即发送停止帧，并补发一帧防止无线丢包导致小车不停
                    sendZeroNow();
                } else {
                    triggerSend();
                }
            });
            box.addView(joy);
            widget.joy = joy;
        } else if (item.type == ControlItem.Type.SLIDER) {
            SeekBar seek = new SeekBar(this);
            LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(dp(200), ViewGroup.LayoutParams.WRAP_CONTENT);
            seek.setLayoutParams(sp);
            ControlItem.Channel ch = item.chVal;
            seek.setMax(Math.max(ch.max - ch.min, 1));
            seek.setProgress(0);
            seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override public void onProgressChanged(SeekBar s, int progress, boolean fromUser) {
                    if (!fromUser) return;
                    ControlItem.Channel c = widget.item.chVal;
                    widget.seekVal = c.min + progress;
                    refreshWidgetValue(widget);
                    if (widget.item.ledLight) {
                        // LED 补光：固件只在 /stream 播放(isStreaming)时才真正输出，
                        // 与网页一致：没开图传时自动先开，再下发 led_intensity
                        if (!mjpegView.isRunning()) {
                            if (mjpegUrl.isEmpty()) {
                                Toast.makeText(MainActivity.this, "请先在图传中设置网址", Toast.LENGTH_SHORT).show();
                                return;
                            }
                            startMjpeg();
                            Toast.makeText(MainActivity.this, "已自动开启图传（LED 需在播放中生效）", Toast.LENGTH_SHORT).show();
                            // 等 /stream 连上（isStreaming=true）后再补发一次当前亮度
                            final int v = widget.seekVal;
                            mainHandler.postDelayed(() -> {
                                if (mjpegView.isRunning()) {
                                    sendCameraControl("led_intensity", v);
                                }
                            }, 700);
                        }
                        sendCameraControl("led_intensity", widget.seekVal);
                    } else {
                        triggerSend();
                    }
                }
                @Override public void onStartTrackingTouch(SeekBar s) {}
                @Override public void onStopTrackingTouch(SeekBar s) {}
            });
            box.addView(seek);
            widget.seek = seek;
        } else { // SWITCH
            ToggleSwitch toggle = new ToggleSwitch(this);
            LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(dp(90), dp(45));
            toggle.setLayoutParams(tp);
            toggle.setOnToggleChangeListener(isOn -> {
                widget.swOn = isOn;
                refreshWidgetValue(widget);
                triggerSend();
            });
            box.addView(toggle);
            widget.toggle = toggle;
        }

        box.addView(value);
        widget.tvVal = value;
        widget.seekVal = item.chVal.min;

        surface.addView(box);
        widgets.add(widget);

        // 布局完成后按保存的归一化坐标摆放
        box.addOnLayoutChangeListener((v, l, t, r, b, ol, ot, or, ob) -> {
            if (v.getWidth() > 0 && v.getHeight() > 0) {
                v.setPivotX(v.getWidth() / 2f);
                v.setPivotY(v.getHeight() / 2f);
                applyWidgetTransform(widget);
            }
        });
        refreshWidgetValue(widget);
    }

    private void applyWidgetTransform(ControlWidget w) {
        int sw = surface.getWidth();
        int sh = surface.getHeight();
        if (sw <= 0 || sh <= 0) return;
        float cx = (float) (w.item.fx * sw);
        float cy = (float) (w.item.fy * sh);
        w.root.setTranslationX(cx - w.root.getWidth() / 2f);
        w.root.setTranslationY(cy - w.root.getHeight() / 2f);
        w.root.setRotation(w.item.angle);
        w.root.setScaleX(w.item.scale);
        w.root.setScaleY(w.item.scale);
        w.root.setBackground(makeBoxBackground(isSelected(w.item)));
    }

    private void setWidgetCenter(ControlWidget w, float cx, float cy) {
        int sw = surface.getWidth();
        int sh = surface.getHeight();
        float w2 = w.root.getWidth() / 2f;
        float h2 = w.root.getHeight() / 2f;
        w.root.setTranslationX(cx - w2);
        w.root.setTranslationY(cy - h2);
        if (sw > 0 && sh > 0) {
            w.item.fx = Math.max(0.0, Math.min(1.0, cx / sw));
            w.item.fy = Math.max(0.0, Math.min(1.0, cy / sh));
        }
    }

    private GradientDrawable makeBoxBackground(boolean selected) {
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.RECTANGLE);
        g.setCornerRadius(dp(12));
        g.setColor(selected ? Color.argb(230, 255, 200, 0) : Color.argb(150, 35, 35, 35));
        return g;
    }

    private ControlWidget widgetOf(ControlItem item) {
        for (ControlWidget w : widgets) {
            if (w.item == item) return w;
        }
        return null;
    }

    private boolean isSelected(ControlItem item) {
        return selectedItem != null && selectedItem == item;
    }

    private void setSelected(ControlItem item) {
        if (selectedItem != null) {
            ControlWidget old = widgetOf(selectedItem);
            if (old != null) old.root.setBackground(makeBoxBackground(false));
        }
        selectedItem = item;
        if (item != null) {
            ControlWidget nw = widgetOf(item);
            if (nw != null) nw.root.setBackground(makeBoxBackground(true));
        }
    }

    private void refreshWidgetValue(ControlWidget w) {
        if (w.tvVal == null) return;
        if (w.item.type == ControlItem.Type.JOYSTICK) {
            w.tvVal.setText(String.format("X: %.2f  Y: %.2f", w.joyX, w.joyY));
        } else if (w.item.type == ControlItem.Type.SLIDER) {
            w.tvVal.setText("当前值: " + w.seekVal);
        } else {
            w.tvVal.setText(w.swOn ? "开" : "关");
        }
    }

    private ControlItem hitTestControl(float x, float y) {
        for (int i = widgets.size() - 1; i >= 0; i--) {
            ControlWidget w = widgets.get(i);
            float cx = w.root.getX() + w.root.getWidth() / 2f;
            float cy = w.root.getY() + w.root.getHeight() / 2f;
            float halfW = w.root.getWidth() / 2f * w.root.getScaleX();
            float halfH = w.root.getHeight() / 2f * w.root.getScaleY();
            if (Math.abs(x - cx) <= halfW && Math.abs(y - cy) <= halfH) {
                return w.item;
            }
        }
        return null;
    }

    // =====================================================================
    // 调节模式（布局/缩放/旋转）
    // =====================================================================
    private void toggleRotateMode() {
        rotateMode = !rotateMode;
        setRotateButtonStyle(rotateMode);
        if (rotateMode) {
            overlay.setVisibility(View.VISIBLE);
            setSelected(null);
            for (ControlWidget w : widgets) {
                if (w.joy != null) w.joy.setShowAxis(true);
            }
            Toast.makeText(this, "调节模式：单击选中，长按移动，双指旋转/缩放", Toast.LENGTH_LONG).show();
        } else {
            overlay.setVisibility(View.GONE);
            setSelected(null);
            for (ControlWidget w : widgets) {
                if (w.joy != null) w.joy.setShowAxis(false);
            }
            saveState();
            Toast.makeText(this, "已退出调节模式", Toast.LENGTH_SHORT).show();
        }
    }

    // =====================================================================
    // 范围 / 控件管理
    // =====================================================================
    private void onRangeClick() {
        if (items.isEmpty()) {
            Toast.makeText(this, "还没有控件，请先点“＋－控件”添加", Toast.LENGTH_SHORT).show();
            return;
        }
        if (rotateMode && selectedItem != null && items.contains(selectedItem)) {
            showItemManager(selectedItem);
            return;
        }
        String[] labels = new String[items.size()];
        for (int i = 0; i < items.size(); i++) labels[i] = items.get(i).label;
        new AlertDialog.Builder(this)
                .setTitle("选择要设置的控件")
                .setItems(labels, (d, which) -> showItemManager(items.get(which)))
                .setNegativeButton("取消", null)
                .show();
    }

    private void showItemManager(ControlItem item) {
        // 删除入口已移到“＋－控件”对话框左下角，这里只配置量程/类型与重命名
        List<String> opts = new ArrayList<>();
        if (item.type == ControlItem.Type.JOYSTICK) {
            opts.add("设置 X 轴量程/类型");
            opts.add("设置 Y 轴量程/类型");
        } else if (item.type == ControlItem.Type.SLIDER) {
            if (item.ledLight) {
                opts.add("LED 补光固定 0~255（控制摄像头，不可改）");
            } else {
                opts.add("设置量程/类型");
            }
        } else {
            opts.add("开关固定发送单字节 0/1（无其他设置）");
        }
        opts.add("重命名");

        String[] arr = opts.toArray(new String[0]);
        new AlertDialog.Builder(this)
                .setTitle(item.label)
                .setItems(arr, (d, which) -> {
                    int idx = which;
                    if (item.type == ControlItem.Type.JOYSTICK) {
                        if (idx == 0) { editChannel(item, item.chX, item.label + " X 轴"); return; }
                        if (idx == 1) { editChannel(item, item.chY, item.label + " Y 轴"); return; }
                        idx -= 2;
                    } else if (item.type == ControlItem.Type.SLIDER) {
                        if (!item.ledLight && idx == 0) {
                            editChannel(item, item.chVal, item.label + " 量程");
                            return;
                        }
                        idx -= 1;   // LED：第一条为说明文字
                    } else {
                        idx -= 1;   // 第一条为说明文字
                    }
                    if (idx == 0) renameItem(item);
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private void editChannel(ControlItem item, ControlItem.Channel ch, String title) {
        ControlSettingDialog.show(this, title, ch.min, ch.max, ch.type, (min, max, type) -> {
            ch.min = min;
            ch.max = max;
            ch.type = type;
            ControlWidget w = widgetOf(item);
            if (w != null && item.type == ControlItem.Type.SLIDER && w.seek != null) {
                w.seek.setMax(Math.max(max - min, 1));
                int p = Math.max(0, Math.min(w.seekVal - min, max - min));
                w.seek.setProgress(p);
            }
            saveState();
            sendPacketNow();
            Toast.makeText(this, item.label + " 参数已更新", Toast.LENGTH_SHORT).show();
        });
    }

    private void renameItem(ControlItem item) {
        EditText et = new EditText(this);
        et.setText(item.label);
        et.setSelectAllOnFocus(true);
        new AlertDialog.Builder(this)
                .setTitle("重命名")
                .setView(et)
                .setPositiveButton("确定", (d, w) -> {
                    String name = et.getText().toString().trim();
                    if (name.isEmpty()) return;
                    item.label = name;
                    ControlWidget cw = widgetOf(item);
                    if (cw != null) cw.tvTitle.setText(name);
                    saveState();
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private void deleteItem(ControlItem item) {
        new AlertDialog.Builder(this)
                .setTitle("删除控件")
                .setMessage("确定删除 " + item.label + " 吗？")
                .setPositiveButton("删除", (d, w) -> {
                    ControlWidget cw = widgetOf(item);
                    if (cw != null) {
                        surface.removeView(cw.root);
                        widgets.remove(cw);
                    }
                    items.remove(item);
                    if (selectedItem == item) selectedItem = null;
                    saveState();
                })
                .setNegativeButton("取消", null)
                .show();
    }

    // =====================================================================
    // 连接与数据包
    // =====================================================================
    private void setupClickListeners() {
        btnConnect.setOnClickListener(v -> {
            if (bluetoothService.isConnected()) {
                bluetoothService.disconnect();
            } else {
                setConnectUi(STATE_CONNECTING);
                if (!bluetoothAdapter.isEnabled()) {
                    Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                    startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
                } else {
                    Intent intent = new Intent(MainActivity.this, DeviceListActivity.class);
                    startActivityForResult(intent, REQUEST_SELECT_DEVICE);
                }
            }
        });
    }

    /**
     * 控件状态变化时触发发送。
     * 9600bps 下每字节约 1.04ms，为避免下位机 UART/蓝牙模块缓冲积压导致丢包，
     * 两次发送之间至少间隔一个包长的传输时间；同时保证"最新一帧"（如摇杆归零）
     * 一定会在间隔结束后补发出去，不会因状态频繁变化而被反复推迟或丢弃。
     */
    private void triggerSend() {
        if (!bluetoothService.isConnected()) return;
        long now = System.currentTimeMillis();
        if (now >= nextSendTime) {
            nextSendTime = now + sendIntervalMs();
            sendPacketNow();
        } else if (!sendPending) {
            sendPending = true;
            long delay = nextSendTime - now;
            mainHandler.postDelayed(pendingSend, Math.max(delay, 1));
        }
    }

    private void firePendingSend() {
        sendPending = false;
        if (bluetoothService.isConnected()) {
            nextSendTime = System.currentTimeMillis() + sendIntervalMs();
            sendPacketNow();
        }
    }

    /**
     * 摇杆松开归零：绕过节流立即发一帧（此时控件值已归零），
     * 稍后再补发两帧，保证无线偶尔丢帧时下位机也能收到停止命令。
     */
    private void sendZeroNow() {
        if (!bluetoothService.isConnected()) return;
        mainHandler.removeCallbacks(pendingSend);
        sendPending = false;
        nextSendTime = System.currentTimeMillis() + sendIntervalMs();
        sendPacketNow();
        for (int i = 1; i <= 2; i++) {
            mainHandler.postDelayed(() -> {
                if (bluetoothService.isConnected()) sendPacketNow();
            }, 15L * i);
        }
    }

    /** 当前包总字节数 */
    private int packetByteCount() {
        int n = headerBytes.length + tailBytes.length;
        for (ControlWidget w : widgets) {
            n += widgetBytesLength(w);
        }
        return n;
    }

    /** 按 9600bps 计算当前发送间隔（ms） */
    private int sendIntervalMs() {
        return intervalForBytes(packetByteCount());
    }

    /** 9600bps ≈ 960B/s，每字节约 1.0417ms，留 25% 余量，下限 15ms */
    private static int intervalForBytes(int bytes) {
        int need = (int) Math.ceil(bytes * 1000.0 / 960.0 * 1.25);
        return Math.max(15, need);
    }

    private void sendPacketNow() {
        if (!bluetoothService.isConnected()) return;

        int total = headerBytes.length + tailBytes.length;
        for (ControlWidget w : widgets) {
            total += widgetBytesLength(w);
        }
        if (total == 0) return;
        ByteBuffer buffer = ByteBuffer.allocate(total);
        buffer.put(headerBytes);
        for (ControlWidget w : widgets) {
            buffer.put(widgetBytes(w));
        }
        buffer.put(tailBytes);
        bluetoothService.sendData(buffer.array());
    }

    private int widgetBytesLength(ControlWidget w) {
        return widgetBytes(w).length;
    }

    private byte[] widgetBytes(ControlWidget w) {
        if (w.item.type == ControlItem.Type.JOYSTICK) {
            byte[] bx = encodeChannel(physicalOf(w.joyX, w.item.chX), w.item.chX.type);
            byte[] by = encodeChannel(physicalOf(w.joyY, w.item.chY), w.item.chY.type);
            byte[] out = new byte[bx.length + by.length];
            System.arraycopy(bx, 0, out, 0, bx.length);
            System.arraycopy(by, 0, out, bx.length, by.length);
            return out;
        }
        if (w.item.type == ControlItem.Type.SLIDER) {
            if (w.item.ledLight) return new byte[0];   // LED 只控摄像头，不进蓝牙包
            return encodeChannel(w.seekVal, w.item.chVal.type);
        }
        // SWITCH：固定单字节 0/1
        return new byte[]{(byte) (w.swOn ? 1 : 0)};
    }

    /** 摇杆原始值 [-1,1] 映射到通道量程后的物理值 */
    private double physicalOf(float raw, ControlItem.Channel ch) {
        return ch.min + (raw + 1.0) / 2.0 * (ch.max - ch.min);
    }

    private byte[] encodeChannel(double physicalValue, DataType type) {
        switch (type) {
            case UINT8:
                return new byte[]{(byte) clamp(Math.round(physicalValue), 0, 255)};
            case INT8:
                return new byte[]{(byte) clamp(Math.round(physicalValue), -128, 127)};
            case UINT16:
                return ByteBuffer.allocate(2).order(ByteOrder.LITTLE_ENDIAN)
                        .putShort((short) clamp(Math.round(physicalValue), 0, 65535)).array();
            case INT16:
                return ByteBuffer.allocate(2).order(ByteOrder.LITTLE_ENDIAN)
                        .putShort((short) clamp(Math.round(physicalValue), -32768, 32767)).array();
            case FLOAT32:
                return ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN)
                        .putFloat((float) physicalValue).array();
            default:
                return new byte[0];
        }
    }

    private static int clamp(long v, int lo, int hi) {
        return (int) Math.max(lo, Math.min(hi, v));
    }

    private String bytesToHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder();
        for (byte b : bytes) {
            sb.append(String.format("%02X ", b));
        }
        return sb.toString().trim();
    }

    // =====================================================================
    // 全屏 / 横竖屏 / 单位
    // =====================================================================
    private void applyFullscreen() {
        WindowInsetsControllerCompat controller =
                WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
        controller.hide(WindowInsetsCompat.Type.systemBars());
        controller.setSystemBarsBehavior(
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            applyFullscreen();
        }
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    // =====================================================================
    // 悬浮窗（接收数据显示）
    // =====================================================================
    private void initFloatingWindow() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!Settings.canDrawOverlays(this)) {
                Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                startActivityForResult(intent, REQUEST_OVERLAY_PERMISSION);
                return;
            }
        }
        createFloatingWindow();
    }

    private void createFloatingWindow() {
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        floatingView = LayoutInflater.from(this).inflate(R.layout.floating_window, null);
        tvFloatingData = floatingView.findViewById(R.id.tv_floating_data);
        btnCollapse = floatingView.findViewById(R.id.btnCollapse);
        btnFloatToggle = floatingView.findViewById(R.id.btnFloatToggle);
        floatingTitleBar = floatingView.findViewById(R.id.floatingTitleBar);
        btnExpandFromCollapsed = floatingView.findViewById(R.id.btnExpandFromCollapsed);

        tvFloatingData.setMovementMethod(new ScrollingMovementMethod());

        joyDiameter = dp(110);
        expandedWidth = joyDiameter * 2;
        expandedHeight = joyDiameter;
        collapsedSize = expandedWidth / 5;
        fullscreenWidth = WindowManager.LayoutParams.MATCH_PARENT;
        fullscreenHeight = WindowManager.LayoutParams.MATCH_PARENT;

        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O ?
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY :
                WindowManager.LayoutParams.TYPE_PHONE;
        floatingParams = new WindowManager.LayoutParams(
                expandedWidth, expandedHeight, type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
        );
        floatingParams.gravity = Gravity.TOP | Gravity.START;
        floatingParams.x = 100;
        floatingParams.y = 200;
        originalX = 100;
        originalY = 200;

        windowManager.addView(floatingView, floatingParams);

        // 长按悬浮窗任意区域拖动（展开/收起状态均支持；全屏时禁用拖动）
        FloatingDragLayout dragRoot = (FloatingDragLayout) floatingView;
        dragRoot.setOnDragListener(new FloatingDragLayout.OnDragListener() {
            private int dragBaseX, dragBaseY;

            @Override
            public void onDragStart() {
                dragBaseX = floatingParams.x;
                dragBaseY = floatingParams.y;
            }

            @Override
            public void onDragMove(float dx, float dy) {
                if (currentState == FloatState.FULLSCREEN) return;
                floatingParams.x = dragBaseX + (int) dx;
                floatingParams.y = dragBaseY + (int) dy;
                windowManager.updateViewLayout(floatingView, floatingParams);
            }

            @Override
            public void onDragEnd() {
            }
        });

        // 收起状态的长按拖动（修复瞬移问题）
        btnExpandFromCollapsed.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    collapsedDragStartX = event.getRawX();
                    collapsedDragStartY = event.getRawY();
                    collapsedStartPosX = floatingParams.x;
                    collapsedStartPosY = floatingParams.y;
                    isCollapsedDragging = false;
                    hasMovedInCollapsed = false;
                    return true;
                case MotionEvent.ACTION_MOVE:
                    float dx = event.getRawX() - collapsedDragStartX;
                    float dy = event.getRawY() - collapsedDragStartY;
                    if (Math.hypot(dx, dy) > 10) {
                        isCollapsedDragging = true;
                        hasMovedInCollapsed = true;
                        floatingParams.x = collapsedStartPosX + (int) dx;
                        floatingParams.y = collapsedStartPosY + (int) dy;
                        windowManager.updateViewLayout(floatingView, floatingParams);
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                    if (!hasMovedInCollapsed) {
                        setFloatState(FloatState.EXPANDED);
                    }
                    isCollapsedDragging = false;
                    hasMovedInCollapsed = false;
                    return true;
            }
            return false;
        });

        // 收起 / 全屏-小屏切换（默认小屏 EXPANDED）
        btnCollapse.setOnClickListener(v -> setFloatState(FloatState.COLLAPSED));
        btnFloatToggle.setOnClickListener(v -> {
            if (currentState == FloatState.FULLSCREEN) {
                setFloatState(FloatState.EXPANDED);
            } else {
                setFloatState(FloatState.FULLSCREEN);
            }
        });
    }

    private void setFloatState(FloatState newState) {
        if (currentState == newState) return;

        LinearLayout titleBar = floatingView.findViewById(R.id.floatingTitleBar);
        TextView dataArea = floatingView.findViewById(R.id.tv_floating_data);
        Button expandBtn = floatingView.findViewById(R.id.btnExpandFromCollapsed);

        int width, height;
        switch (newState) {
            case COLLAPSED:
                width = collapsedSize;
                height = collapsedSize;
                titleBar.setVisibility(View.GONE);
                dataArea.setVisibility(View.GONE);
                expandBtn.setVisibility(View.VISIBLE);
                break;
            case EXPANDED:
                width = expandedWidth;
                height = expandedHeight;
                titleBar.setVisibility(View.VISIBLE);
                dataArea.setVisibility(View.VISIBLE);
                expandBtn.setVisibility(View.GONE);
                break;
            case FULLSCREEN:
                width = fullscreenWidth;
                height = fullscreenHeight;
                titleBar.setVisibility(View.VISIBLE);
                dataArea.setVisibility(View.VISIBLE);
                expandBtn.setVisibility(View.GONE);
                originalX = floatingParams.x;
                originalY = floatingParams.y;
                floatingParams.x = 0;
                floatingParams.y = 0;
                break;
            default:
                return;
        }
        floatingParams.width = width;
        floatingParams.height = height;
        if (newState == FloatState.FULLSCREEN) {
            floatingParams.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS;
        } else {
            floatingParams.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
        }
        windowManager.updateViewLayout(floatingView, floatingParams);

        if (currentState == FloatState.FULLSCREEN && newState != FloatState.FULLSCREEN) {
            floatingParams.x = originalX;
            floatingParams.y = originalY;
            floatingParams.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
            windowManager.updateViewLayout(floatingView, floatingParams);
        }
        currentState = newState;

        // 切换键文字：全屏时提示"小屏"，其余提示"全屏"
        Button toggleBtn = floatingView.findViewById(R.id.btnFloatToggle);
        if (toggleBtn != null) {
            toggleBtn.setText(newState == FloatState.FULLSCREEN ? "小屏" : "全屏");
        }
    }

    private void updateFloatingData(byte[] data) {
        if (tvFloatingData == null) return;

        String timeStr = timeFormat.format(new Date());
        String content;

        String utf8Text = new String(data, java.nio.charset.StandardCharsets.UTF_8);
        boolean hasNonPrintable = false;
        for (char c : utf8Text.toCharArray()) {
            if (c < 0x20 && c != '\n' && c != '\r' && c != '\t') {
                hasNonPrintable = true;
                break;
            }
        }
        if (!hasNonPrintable && !utf8Text.trim().isEmpty()) {
            content = utf8Text;
        } else {
            content = bytesToHex(data);
        }

        String messageLine = String.format("[%s] %s", timeStr, content);

        synchronized (receivedMessages) {
            receivedMessages.add(messageLine);
            while (receivedMessages.size() > MAX_MESSAGES) {
                receivedMessages.remove(0);
            }
            StringBuilder displayBuilder = new StringBuilder();
            for (String msg : receivedMessages) {
                displayBuilder.append(msg).append("\n");
            }
            String displayText = displayBuilder.toString().trim();
            runOnUiThread(() -> {
                tvFloatingData.setText(displayText);
                tvFloatingData.post(() -> {
                    if (tvFloatingData.getLayout() != null) {
                        int scrollAmount = tvFloatingData.getLayout().getLineTop(tvFloatingData.getLineCount()) - tvFloatingData.getHeight();
                        if (scrollAmount > 0) tvFloatingData.scrollTo(0, scrollAmount);
                    }
                });
            });
        }
    }

    // =====================================================================
    // 权限
    // =====================================================================
    private void checkPermissionsAndEnableBluetooth() {
        String[] permissions;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            permissions = new String[]{Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.ACCESS_FINE_LOCATION};
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            permissions = new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION};
        } else {
            permissions = new String[]{};
        }
        boolean allGranted = true;
        for (String perm : permissions) {
            if (ContextCompat.checkSelfPermission(this, perm) != PackageManager.PERMISSION_GRANTED) {
                allGranted = false;
                break;
            }
        }
        if (!allGranted) {
            ActivityCompat.requestPermissions(this, permissions, PERMISSION_REQUEST_CODE);
        } else {
            if (!bluetoothAdapter.isEnabled()) {
                Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_CODE) {
            for (int result : grantResults) {
                if (result != PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(this, "需要必要权限才能使用蓝牙", Toast.LENGTH_SHORT).show();
                    finish();
                    return;
                }
            }
            if (!bluetoothAdapter.isEnabled()) {
                Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_SELECT_DEVICE && resultCode == RESULT_OK) {
            String address = data.getStringExtra("device_address");
            BluetoothDevice device = bluetoothAdapter.getRemoteDevice(address);
            setConnectUi(STATE_CONNECTING);
            bluetoothService.connect(device);
        } else if (requestCode == REQUEST_ENABLE_BT) {
            if (resultCode == RESULT_OK) {
                Toast.makeText(this, "蓝牙已开启", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "需要蓝牙才能工作", Toast.LENGTH_SHORT).show();
                finish();
            }
        } else if (requestCode == REQUEST_OVERLAY_PERMISSION) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (Settings.canDrawOverlays(this)) {
                    createFloatingWindow();
                } else {
                    Toast.makeText(this, "需要悬浮窗权限才能显示接收数据", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (!isChangingConfigurations()) {
            bluetoothService.disconnect();
            bluetoothService.setConnectionListener(null);
        }
        mainHandler.removeCallbacks(rateUpdater);
        mainHandler.removeCallbacks(pendingSend);
        if (mjpegView != null) {
            mjpegView.stop();
        }
        if (floatingView != null && windowManager != null) {
            windowManager.removeView(floatingView);
        }
    }

    // =====================================================================
    // 控件运行时包装
    // =====================================================================
    private class ControlWidget {
        final ControlItem item;
        final View root;
        final TextView tvTitle;
        TextView tvVal;
        JoystickView joy;
        SeekBar seek;
        ToggleSwitch toggle;
        float joyX, joyY;
        int seekVal;
        boolean swOn;

        ControlWidget(ControlItem item, View root, TextView tvTitle) {
            this.item = item;
            this.root = root;
            this.tvTitle = tvTitle;
            this.seekVal = item.chVal.min;
        }
    }
}
