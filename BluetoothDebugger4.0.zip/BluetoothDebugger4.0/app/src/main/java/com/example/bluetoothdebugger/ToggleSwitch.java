package com.example.bluetoothdebugger;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

public class ToggleSwitch extends View {
    private Paint bgPaint;
    private Paint thumbPaint;
    private RectF bgRect;
    private float thumbX;
    private float thumbRadius;
    private float switchWidth;
    private float switchHeight;
    private boolean isOn = false;
    private OnToggleChangeListener listener;

    public interface OnToggleChangeListener {
        void onToggleChanged(boolean isOn);
    }

    public ToggleSwitch(Context context) {
        super(context);
        init();
    }

    public ToggleSwitch(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    private void init() {
        bgPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        thumbPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        thumbPaint.setColor(Color.WHITE);
        updateBackgroundColor();
        setClickable(true);
        setFocusable(true);
    }

    private void updateBackgroundColor() {
        if (isOn) {
            // 70% 透明度绿色 (#B3 = 70%, 原绿色 #34C759)
            bgPaint.setColor(Color.parseColor("#B334C759"));
        } else {
            bgPaint.setColor(Color.parseColor("#E5E5EA"));
        }
        invalidate();
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        switchWidth = w;
        switchHeight = h;
        thumbRadius = switchHeight / 2f - 4;
        bgRect = new RectF(0, 0, switchWidth, switchHeight);
        updateThumbPosition();
    }

    private void updateThumbPosition() {
        if (isOn) {
            thumbX = switchWidth - thumbRadius - 2;
        } else {
            thumbX = thumbRadius + 2;
        }
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        canvas.drawRoundRect(bgRect, switchHeight / 2, switchHeight / 2, bgPaint);
        canvas.drawCircle(thumbX, switchHeight / 2, thumbRadius, thumbPaint);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (event.getAction() == MotionEvent.ACTION_UP) {
            isOn = !isOn;
            updateBackgroundColor();
            updateThumbPosition();
            if (listener != null) {
                listener.onToggleChanged(isOn);
            }
            performClick();
            return true;
        }
        return super.onTouchEvent(event);
    }

    @Override
    public boolean performClick() {
        super.performClick();
        return true;
    }

    public void setOnToggleChangeListener(OnToggleChangeListener listener) {
        this.listener = listener;
    }

    public boolean isOn() {
        return isOn;
    }
}