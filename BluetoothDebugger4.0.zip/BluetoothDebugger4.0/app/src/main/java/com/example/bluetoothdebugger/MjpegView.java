package com.example.bluetoothdebugger;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.os.Handler;
import android.os.Looper;
import android.util.AttributeSet;
import android.view.View;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * MJPEG 图传视图：直接拉取 ESP32-CAM 等设备的网页视频流，
 * 解码显示为控件层下方的实时背景。支持画面缩放与旋转。
 */
public class MjpegView extends View {

    private volatile boolean running = false;
    private volatile Thread worker;
    private volatile HttpURLConnection conn;

    private String url = "";
    private Bitmap frame;
    private String statusText = "";
    private float zoom = 1f;          // 1 = 适应视图
    private int rotationDeg = 0;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Paint paint = new Paint(Paint.FILTER_BITMAP_FLAG);
    private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF dst = new RectF();

    public MjpegView(Context context) {
        super(context);
        init();
    }

    public MjpegView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public MjpegView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        textPaint.setColor(Color.WHITE);
        textPaint.setTextSize(28);
        textPaint.setTextAlign(Paint.Align.CENTER);
        setBackgroundColor(Color.BLACK);
    }

    /** 设置画面缩放与旋转（度，取 0/90/180/270） */
    public void setConfig(float zoom, int rotationDeg) {
        this.zoom = Math.max(0.1f, zoom);
        this.rotationDeg = ((rotationDeg % 360) + 360) % 360;
        invalidate();
    }

    /** 开始播放指定网址的 MJPEG 流（空网址则停止） */
    public void start(String streamUrl) {
        stop();
        this.url = streamUrl == null ? "" : streamUrl.trim();
        if (url.isEmpty()) {
            frame = null;
            statusText = "";
            invalidate();
            return;
        }
        running = true;
        worker = new Thread(this::runLoop, "mjpeg-worker");
        worker.setDaemon(true);
        worker.start();
    }

    public void stop() {
        running = false;
        HttpURLConnection c = conn;
        if (c != null) {
            try { c.disconnect(); } catch (Exception ignored) {}
            conn = null;
        }
        Thread t = worker;
        worker = null;
        if (t != null) t.interrupt();
    }

    public boolean isRunning() {
        return running;
    }

    // ---------------- 工作线程 ----------------

    private void runLoop() {
        while (running) {
            try {
                connectOnce();
            } catch (Throwable e) {
                if (!running) break;
                setStatus("图传连接失败，重试中…");
                try { Thread.sleep(1500); } catch (InterruptedException ie) { break; }
            }
        }
    }

    private void connectOnce() throws IOException {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        conn = c;
        c.setConnectTimeout(4000);
        c.setReadTimeout(8000);
        c.setRequestProperty("Accept", "*/*");
        c.connect();
        if (c.getResponseCode() != 200) {
            int code = c.getResponseCode();
            c.disconnect();
            conn = null;
            throw new IOException("HTTP " + code);
        }
        BufferedInputStream in = new BufferedInputStream(c.getInputStream());
        setStatus("正在连接图传…");

        // 跳过 HTTP 头，直到第一个边界 "--"
        readUntilBoundary(in);

        while (running) {
            // 读取帧头（Content-Length）
            int length = readHeadersUntilEmpty(in);
            if (length <= 0) {
                readUntilBoundary(in);
                continue;
            }
            byte[] data = readExact(in, length);
            final Bitmap bmp = BitmapFactory.decodeByteArray(data, 0, data.length);
            if (bmp != null) {
                handler.post(() -> {
                    frame = bmp;
                    statusText = "";
                    invalidate();
                });
            }
            // 消费帧后残留的 \r\n 与下一个 --frame
            readUntilBoundary(in);
        }
    }

    private void readUntilBoundary(BufferedInputStream in) throws IOException {
        while (running) {
            String line = readAsciiLine(in);
            if (line == null) throw new IOException("stream end");
            if (line.startsWith("--")) return;
        }
    }

    private int readHeadersUntilEmpty(BufferedInputStream in) throws IOException {
        int length = -1;
        while (running) {
            String line = readAsciiLine(in);
            if (line == null) throw new IOException("stream end");
            if (line.isEmpty()) break;
            String lower = line.toLowerCase();
            if (lower.startsWith("content-length:")) {
                try {
                    length = Integer.parseInt(line.substring(line.indexOf(':') + 1).trim());
                } catch (NumberFormatException ignored) {
                }
            }
        }
        return length;
    }

    private byte[] readExact(BufferedInputStream in, int length) throws IOException {
        byte[] data = new byte[length];
        int off = 0;
        while (off < length) {
            int n = in.read(data, off, length - off);
            if (n < 0) throw new IOException("stream end");
            off += n;
        }
        return data;
    }

    /** 读取一行 ASCII（含 \n），去掉行尾的 \r\n */
    private String readAsciiLine(BufferedInputStream in) throws IOException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        int b;
        while (running) {
            b = in.read();
            if (b < 0) {
                return bos.size() == 0 ? null : null; // EOF
            }
            if (b == '\n') break;
            bos.write(b);
        }
        byte[] arr = bos.toByteArray();
        int len = arr.length;
        if (len > 0 && arr[len - 1] == '\r') len--;
        return new String(arr, 0, len, "ISO-8859-1");
    }

    private void setStatus(final String text) {
        handler.post(() -> {
            statusText = text;
            invalidate();
        });
    }

    // ---------------- 绘制 ----------------

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (frame == null || frame.isRecycled()) {
            if (!statusText.isEmpty()) {
                canvas.drawText(statusText, getWidth() / 2f, getHeight() / 2f, textPaint);
            }
            return;
        }
        int bw = frame.getWidth();
        int bh = frame.getHeight();
        if (bw == 0 || bh == 0) return;

        float cw = getWidth();
        float ch = getHeight();
        float rad = (float) Math.toRadians(rotationDeg);
        float absCos = (float) Math.abs(Math.cos(rad));
        float absSin = (float) Math.abs(Math.sin(rad));

        // 旋转后取景框适配视图
        float scale = Math.min(
                cw / (bw * absCos + bh * absSin),
                ch / (bw * absSin + bh * absCos));
        scale = Math.max(scale, 0.01f) * zoom;

        float dw = bw * scale;
        float dh = bh * scale;

        canvas.save();
        canvas.rotate(rotationDeg, cw / 2f, ch / 2f);
        dst.set(cw / 2f - dw / 2f, ch / 2f - dh / 2f, cw / 2f + dw / 2f, ch / 2f + dh / 2f);
        canvas.drawBitmap(frame, null, dst, paint);
        canvas.restore();
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        stop();
    }
}
