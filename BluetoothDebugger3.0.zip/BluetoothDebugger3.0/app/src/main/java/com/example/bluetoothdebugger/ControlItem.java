package com.example.bluetoothdebugger;

import org.json.JSONObject;

/**
 * 动态控件模型：类型、显示名、屏幕归一化坐标、旋转角、各通道量程/类型。
 * 支持 JSON 序列化以便持久化到 SharedPreferences。
 */
public class ControlItem {
    public enum Type { JOYSTICK, SLIDER, SWITCH }

    /** 单个数据通道的量程与数据类型配置 */
    public static class Channel {
        public int min = 0;
        public int max = 100;
        public DataType type = DataType.UINT8;

        public Channel() {
        }

        public Channel(int min, int max, DataType type) {
            this.min = min;
            this.max = max;
            this.type = type;
        }

        public JSONObject toJson() {
            try {
                JSONObject o = new JSONObject();
                o.put("min", min);
                o.put("max", max);
                o.put("type", type.name());
                return o;
            } catch (Exception e) {
                return new JSONObject();
            }
        }

        public static Channel fromJson(JSONObject o) {
            Channel c = new Channel();
            if (o == null) return c;
            c.min = o.optInt("min", c.min);
            c.max = o.optInt("max", c.max);
            try {
                c.type = DataType.valueOf(o.optString("type", "UINT8"));
            } catch (Exception e) {
                c.type = DataType.UINT8;
            }
            return c;
        }
    }

    public Type type;
    public String label;
    public double fx;       // 控件中心 X：相对画布宽度的归一化坐标 (0~1)
    public double fy;       // 控件中心 Y：相对画布高度的归一化坐标 (0~1)
    public float angle;     // 旋转角（度）
    public float scale = 1f; // 缩放（1 = 原始大小；面积不小于原始的 1/4，即不小于 0.5）

    public Channel chX;     // 摇杆 X 轴通道
    public Channel chY;     // 摇杆 Y 轴通道
    public Channel chVal;   // 滑杆通道

    public ControlItem(Type type, String label) {
        this.type = type;
        this.label = label;
        this.fx = 0.5;
        this.fy = 0.5;
        this.angle = 0f;
        this.chX = new Channel(-90, 90, DataType.INT8);
        this.chY = new Channel(-90, 90, DataType.INT8);
        this.chVal = new Channel(0, 100, DataType.UINT8);
    }

    private ControlItem() {
    }

    public JSONObject toJson() {
        try {
            JSONObject o = new JSONObject();
            o.put("type", type.name());
            o.put("label", label);
            o.put("fx", fx);
            o.put("fy", fy);
            o.put("angle", angle);
            o.put("scale", scale);
            o.put("chX", chX.toJson());
            o.put("chY", chY.toJson());
            o.put("chVal", chVal.toJson());
            return o;
        } catch (Exception e) {
            return new JSONObject();
        }
    }

    public static ControlItem fromJson(JSONObject o) {
        ControlItem item = new ControlItem();
        if (o == null) return item;
        try {
            item.type = Type.valueOf(o.optString("type", "SWITCH"));
        } catch (Exception e) {
            item.type = Type.SWITCH;
        }
        item.label = o.optString("label", "控件");
        item.fx = o.optDouble("fx", 0.5);
        item.fy = o.optDouble("fy", 0.5);
        item.angle = (float) o.optDouble("angle", 0.0);
        item.scale = Math.max(0.5f, (float) o.optDouble("scale", 1.0));
        item.chX = Channel.fromJson(o.optJSONObject("chX"));
        item.chY = Channel.fromJson(o.optJSONObject("chY"));
        item.chVal = Channel.fromJson(o.optJSONObject("chVal"));
        return item;
    }
}
