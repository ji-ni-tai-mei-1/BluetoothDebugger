package com.example.bluetoothdebugger;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

/**
 * 工程视图存储（每个工程独立 key + 独立备份 key，多保险）：
 *  - "proj_names"：工程名列表（若丢失，启动时可按 proj_ 文件自动重建）
 *  - "proj_<工程名>"：工程数据；"proj_<工程名>_bak"：最近一次成功保存的备份
 * 读取时主数据缺失/损坏会自动用备份恢复，避免“工程莫名消失”。
 */
public class ProjectStore {

    public static class Project {
        public String name;
        public boolean landscape = true;   // true=横屏
        public byte[] header = new byte[]{(byte) 0xA5};
        public byte[] tail = new byte[]{(byte) 0x5A};
        public final List<ControlItem> items = new ArrayList<>();

        public Project(String name, boolean landscape) {
            this.name = name;
            this.landscape = landscape;
        }
    }

    private static final String PREFS = "proj_store";
    private static final String BAK_PREFS = "proj_bak_store";   // 独立备份文件，与主文件物理隔离
    private static final String KEY_NAMES = "proj_names";
    private static final String BAK_SUFFIX = "_bak";

    // 旧版(≤4.6 早期)把全部工程放一个 key，首次读到会迁移成独立文件后删除
    private static final String LEGACY_KEY = "projects_json";
    private static final String OLD_PREFS = "ctrl_layout";
    private static final String OLD_KEY = "layout_json";

    private ProjectStore() {
    }

    private static String projKey(String name) {
        return "proj_" + name;
    }

    private static String bakKey(String name) {
        return projKey(name) + BAK_SUFFIX;
    }

    private static SharedPreferences sp(Context ctx) {
        return ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    private static SharedPreferences bakSp(Context ctx) {
        return ctx.getSharedPreferences(BAK_PREFS, Context.MODE_PRIVATE);
    }

    private static List<String> readNames(Context ctx) {
        List<String> names = new ArrayList<>();
        try {
            JSONArray arr = new JSONArray(sp(ctx).getString(KEY_NAMES, "[]"));
            for (int i = 0; i < arr.length(); i++) {
                names.add(arr.optString(i, ""));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return names;
    }

    private static void writeNames(Context ctx, List<String> names) {
        JSONArray arr = new JSONArray();
        for (String n : names) arr.put(n);
        sp(ctx).edit().putString(KEY_NAMES, arr.toString()).commit();
    }

    /** 名字列表丢了时，按已存在的 proj_ 文件重建（不含备份 key） */
    private static List<String> discoverNames(Context ctx) {
        List<String> names = new ArrayList<>();
        Map<String, ?> all = sp(ctx).getAll();
        for (String key : all.keySet()) {
            if (key.startsWith("proj_") && key.endsWith(BAK_SUFFIX)) continue;
            if (key.startsWith("proj_")) {
                names.add(key.substring("proj_".length()));
            }
        }
        Collections.sort(names);
        return names;
    }

    private static String readMainJson(Context ctx, String name) {
        String json = sp(ctx).getString(projKey(name), null);
        if (json != null && !json.trim().isEmpty()) return json;
        return null;
    }

    public static List<Project> loadAll(Context ctx) {
        List<String> names = readNames(ctx);
        if (names.isEmpty()) {
            // 优先按现有文件自愈名字列表（防止“列表丢了但文件还在”导致工程消失）
            names = discoverNames(ctx);
            if (!names.isEmpty()) {
                writeNames(ctx, names);
                return loadByName(ctx, names);
            }
            // 真·首启：迁移旧数据或建默认工程
            Project def = migrateOld(ctx);
            if (def != null) {
                saveProject(ctx, def);
                List<String> ns = new ArrayList<>();
                ns.add(def.name);
                writeNames(ctx, ns);
                List<Project> out = new ArrayList<>();
                out.add(def);
                return out;
            }
            return new ArrayList<>();   // 用户主动删光
        }
        return loadByName(ctx, names);
    }

    private static List<Project> loadByName(Context ctx, List<String> names) {
        List<Project> list = new ArrayList<>();
        for (String name : names) {
            if (name == null || name.isEmpty()) continue;
            Project p = get(ctx, name);
            if (p != null) list.add(p);
        }
        return list;
    }

    /** 主数据缺失/损坏时自动用独立备份文件恢复 */
    public static Project get(Context ctx, String name) {
        if (name == null || name.isEmpty()) return null;
        String json = readMainJson(ctx, name);
        Project p = null;
        if (json != null) {
            p = projectFromJson(name, json);
        }
        if (p == null) {
            // 主数据缺失/损坏 → 从独立备份文件恢复
            String bak = bakSp(ctx).getString(bakKey(name), null);
            if (bak != null && !bak.trim().isEmpty()) {
                p = projectFromJson(name, bak);
                if (p != null) {
                    saveProject(ctx, p);   // 备份回写主数据
                }
            }
        }
        if (p == null) return null;
        // 保证名字在列表里
        List<String> names = readNames(ctx);
        if (!names.contains(name)) {
            names.add(name);
            writeNames(ctx, names);
        }
        return p;
    }

    /** 只写当前工程（主 + 备份）；若列表没有则追加，绝不删其它工程 */
    public static void save(Context ctx, Project project) {
        if (project == null || project.name == null || project.name.isEmpty()) return;
        saveProject(ctx, project);
        List<String> names = readNames(ctx);
        if (!names.contains(project.name)) {
            names.add(project.name);
            writeNames(ctx, names);
        }
    }

    public static void delete(Context ctx, String name) {
        sp(ctx).edit()
                .remove(projKey(name))
                .remove(bakKey(name))
                .commit();
        bakSp(ctx).edit()
                .remove(bakKey(name))
                .commit();
        List<String> names = readNames(ctx);
        names.remove(name);
        writeNames(ctx, names);
    }

    private static void saveProject(Context ctx, Project p) {
        try {
            JSONObject o = new JSONObject();
            o.put("landscape", p.landscape);
            o.put("header", bytesToJson(p.header));
            o.put("tail", bytesToJson(p.tail));
            JSONArray cs = new JSONArray();
            for (ControlItem it : p.items) cs.put(it.toJson());
            o.put("controls", cs);
            String json = o.toString();
            // 自检：写出的内容必须能被读回，否则放弃本次保存（保留旧档），避免“保存后工程消失”
            Project check = projectFromJson(p.name, json);
            if (check == null) {
                return;
            }
            sp(ctx).edit()
                    .putString(projKey(p.name), json)
                    .remove(bakKey(p.name))
                    .commit();
            // 独立备份文件写一份（物理隔离，主文件损坏也能恢复）
            bakSp(ctx).edit().putString(bakKey(p.name), json).commit();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static Project projectFromJson(String name, String json) {
        try {
            JSONObject o = new JSONObject(json);
            Project p = new Project(name, o.optBoolean("landscape", true));
            byte[] h = bytesFromJson(o.optJSONArray("header"));
            byte[] t = bytesFromJson(o.optJSONArray("tail"));
            if (h != null) p.header = h;
            if (t != null) p.tail = t;
            JSONArray cs = o.optJSONArray("controls");
            for (int i = 0; i < cs.length(); i++) {
                p.items.add(ControlItem.fromJson(cs.getJSONObject(i)));
            }
            return p;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    /** 迁移：旧多工程列表 → 旧单布局 → 都没有则建默认工程 */
    private static Project migrateOld(Context ctx) {
        String legacy = sp(ctx).getString(LEGACY_KEY, null);
        if (legacy != null && !legacy.trim().isEmpty()) {
            try {
                List<String> names = new ArrayList<>();
                JSONArray arr = new JSONArray(legacy);
                for (int i = 0; i < arr.length(); i++) {
                    JSONObject o = arr.getJSONObject(i);
                    String name = o.optString("name", "工程" + (i + 1));
                    Project p = new Project(name, o.optBoolean("landscape", true));
                    byte[] h = bytesFromJson(o.optJSONArray("header"));
                    byte[] t = bytesFromJson(o.optJSONArray("tail"));
                    if (h != null) p.header = h;
                    if (t != null) p.tail = t;
                    JSONArray cs = o.optJSONArray("controls");
                    for (int j = 0; j < cs.length(); j++) {
                        p.items.add(ControlItem.fromJson(cs.getJSONObject(j)));
                    }
                    saveProject(ctx, p);
                    names.add(name);
                }
                sp(ctx).edit().remove(LEGACY_KEY).commit();
                if (!names.isEmpty()) {
                    writeNames(ctx, names);
                    return null;   // 已迁移多个，不再建默认
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        SharedPreferences old = ctx.getSharedPreferences(OLD_PREFS, Context.MODE_PRIVATE);
        String json = old.getString(OLD_KEY, null);
        if (json != null && !json.trim().isEmpty()) {
            Project p = new Project("默认工程", true);
            try {
                JSONObject root = new JSONObject(json);
                byte[] h = bytesFromJson(root.optJSONArray("header"));
                byte[] t = bytesFromJson(root.optJSONArray("tail"));
                if (h != null) p.header = h;
                if (t != null) p.tail = t;
                JSONArray cs = root.optJSONArray("controls");
                for (int i = 0; i < cs.length(); i++) {
                    p.items.add(ControlItem.fromJson(cs.getJSONObject(i)));
                }
                old.edit().remove(OLD_KEY).commit();
                return p;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        // 全新安装：默认横屏工程
        Project def = new Project("默认工程", true);
        addDefaultItems(def);
        return def;
    }

    private static void addDefaultItems(Project p) {
        ControlItem j1 = new ControlItem(ControlItem.Type.JOYSTICK, "摇杆1");
        j1.fx = 0.16; j1.fy = 0.82;
        j1.chX.min = -95; j1.chX.max = 95;
        j1.chY.min = -95; j1.chY.max = 95;
        ControlItem j2 = new ControlItem(ControlItem.Type.JOYSTICK, "摇杆2");
        j2.fx = 0.84; j2.fy = 0.82;
        j2.chX.min = -95; j2.chX.max = 95;
        j2.chY.min = -95; j2.chY.max = 95;
        // 默认视图只保留两个摇杆（去掉了自带的滑杆与开关）
        p.items.add(j1);
        p.items.add(j2);
    }

    /** 创建新工程时按方向预置默认控件 */
    public static void addNewProjectItems(Project p) {
        if (p.landscape) {
            addDefaultItems(p);
        } else {
            ControlItem j1 = new ControlItem(ControlItem.Type.JOYSTICK, "摇杆1");
            j1.fx = 0.22; j1.fy = 0.70;
            j1.chX.min = -95; j1.chX.max = 95;
            j1.chY.min = -95; j1.chY.max = 95;
            ControlItem j2 = new ControlItem(ControlItem.Type.JOYSTICK, "摇杆2");
            j2.fx = 0.78; j2.fy = 0.70;
            j2.chX.min = -95; j2.chX.max = 95;
            j2.chY.min = -95; j2.chY.max = 95;
            // 默认视图只保留两个摇杆（去掉了自带的滑杆与开关）
            p.items.add(j1);
            p.items.add(j2);
        }
    }

    private static JSONArray bytesToJson(byte[] bytes) {
        JSONArray a = new JSONArray();
        for (byte b : bytes) a.put(b & 0xFF);
        return a;
    }

    private static byte[] bytesFromJson(JSONArray arr) {
        if (arr == null) return null;
        byte[] out = new byte[arr.length()];
        for (int i = 0; i < arr.length(); i++) out[i] = (byte) arr.optInt(i, 0);
        return out;
    }
}
