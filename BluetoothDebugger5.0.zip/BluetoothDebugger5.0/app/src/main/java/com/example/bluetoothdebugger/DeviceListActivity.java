package com.example.bluetoothdebugger;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.bluetooth.le.ScanSettings;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * 设备列表：兼容 HC-05/06（经典 SPP）与 HC-08/HM-10（BLE 串口）等模块。
 * 优化点：
 *  1. 进入页面先做运行时权限自检（Android 12+ 需要 BLUETOOTH_SCAN / BLUETOOTH_CONNECT），
 *     没有权限时扫描是"静默失败"，这是搜不到设备最常见的原因；
 *  2. 经典扫描 + BLE 扫描同时进行，HC-08 这类纯 BLE 模块才可能出现；
 *  3. 已配对 / 经典 / BLE 三类结果合并去重，设备名为空也照常显示（HC-06 常出现 null 名）；
 *  4. 自动多轮扫描（HC-06 只在刚上电的一小段时间可被发现，一轮扫描经常错过）；
 *  5. 实在搜不到时可以直接手输 MAC 地址连接。
 */
public class DeviceListActivity extends Activity {

    private static final int REQ_PERM = 200;
    private static final int ROUND_MS = 12000;     // 每轮扫描时长
    private static final int MAX_ROUNDS = 5;       // 自动扫描轮数
    private static final Pattern MAC_PATTERN =
            Pattern.compile("^[0-9A-Fa-f]{2}(:[0-9A-Fa-f]{2}){5}$");

    private BluetoothAdapter bluetoothAdapter;
    private BluetoothLeScanner leScanner;
    private ArrayAdapter<String> deviceListAdapter;
    private final ArrayList<BluetoothDevice> deviceList = new ArrayList<>();
    private final Map<String, Integer> indexByAddress = new HashMap<>();
    private ListView listView;
    private Button btnScan;
    private TextView tvStatus;
    private EditText etMac;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private int round = 0;
    private boolean receiverRegistered = false;
    private boolean destroy = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_device_list);

        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        deviceListAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1);
        listView = findViewById(R.id.listViewDevices);
        listView.setAdapter(deviceListAdapter);
        btnScan = findViewById(R.id.btnScan);
        tvStatus = findViewById(R.id.tvStatus);
        etMac = findViewById(R.id.etMac);

        listView.setOnItemClickListener((parent, view, position, id) -> {
            if (position < 0 || position >= deviceList.size()) return;
            returnDevice(deviceList.get(position));
        });

        btnScan.setOnClickListener(v -> {
            deviceList.clear();
            indexByAddress.clear();
            deviceListAdapter.clear();
            round = 0;
            startRound();
        });

        findViewById(R.id.btnManualConnect).setOnClickListener(v -> {
            String mac = etMac.getText().toString().trim().toUpperCase(Locale.US);
            if (!MAC_PATTERN.matcher(mac).matches()) {
                toast("MAC 格式不对，例如 98:D3:31:FD:1A:2B");
                return;
            }
            try {
                BluetoothDevice device = bluetoothAdapter.getRemoteDevice(mac);
                returnDevice(device);
            } catch (Exception e) {
                toast("地址无法解析：" + mac);
            }
        });

        if (bluetoothAdapter == null) {
            toast("本机不支持蓝牙");
            finish();
            return;
        }
        if (!hasPermissions()) {
            requestNeededPermissions();
        } else {
            beginScanning();
        }
    }

    // ================= 权限 =================

    private String[] neededPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            // Android 12+ 扫描/连接必须这两个；位置权限用于兼容部分机型的旧扫描实现
            return new String[]{Manifest.permission.BLUETOOTH_SCAN,
                    Manifest.permission.BLUETOOTH_CONNECT,
                    Manifest.permission.ACCESS_FINE_LOCATION};
        }
        return new String[]{Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION};
    }

    private boolean hasPermissions() {
        for (String p : neededPermissions()) {
            if (ContextCompat.checkSelfPermission(this, p) != PackageManager.PERMISSION_GRANTED) {
                return false;
            }
        }
        return true;
    }

    private void requestNeededPermissions() {
        tvStatus.setText("缺少蓝牙权限，正在申请…");
        ActivityCompat.requestPermissions(this, neededPermissions(), REQ_PERM);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != REQ_PERM) return;
        if (hasPermissions()) {
            beginScanning();
        } else {
            tvStatus.setText("没有蓝牙扫描权限，无法搜索设备（可在此页重新授权后重试）");
            toast("请允许“附近的设备”权限，否则搜不到模块");
        }
    }

    // ================= 扫描 =================

    private void beginScanning() {
        if (!bluetoothAdapter.isEnabled()) {
            toast("请先打开手机蓝牙");
            tvStatus.setText("蓝牙未开启");
            return;
        }
        if (!receiverRegistered) {
            IntentFilter filter = new IntentFilter();
            filter.addAction(BluetoothDevice.ACTION_FOUND);
            filter.addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED);
            filter.addAction(BluetoothDevice.ACTION_BOND_STATE_CHANGED);
            filter.addAction(BluetoothAdapter.ACTION_STATE_CHANGED);
            registerReceiver(receiver, filter);
            receiverRegistered = true;
        }
        showBondedDevices();
        round = 0;
        startRound();
    }

    private void startRound() {
        if (destroy) return;
        if (!hasPermissions() || !bluetoothAdapter.isEnabled()) return;
        round++;
        if (round > MAX_ROUNDS) {
            tvStatus.setText("扫描结束：共发现 " + deviceList.size()
                    + " 个设备。HC-06 只在刚上电时可被发现，可给模块重新上电后点“扫描设备”");
            return;
        }
        tvStatus.setText("扫描中… 第 " + round + "/" + MAX_ROUNDS + " 轮（经典 + BLE）");
        startClassicDiscovery();
        startBleScan();

        handler.postDelayed(() -> {
            if (destroy) return;
            stopBleScan();
            try {
                if (bluetoothAdapter.isDiscovering()) bluetoothAdapter.cancelDiscovery();
            } catch (Exception ignored) {
            }
            // 上一轮没扫到就自动再来一轮（HC-06 常错过第一轮）
            if (!deviceList.isEmpty() && round >= 2) {
                tvStatus.setText("已发现 " + deviceList.size() + " 个设备，仍在扫描…（可随时点击连接）");
            }
            startRound();
        }, ROUND_MS);
    }

    private void startClassicDiscovery() {
        try {
            // 部分机型必须先取消再启动，否则 startDiscovery 直接返回 false
            if (bluetoothAdapter.isDiscovering()) bluetoothAdapter.cancelDiscovery();
            boolean ok = bluetoothAdapter.startDiscovery();
            if (!ok) {
                handler.postDelayed(() -> {
                    try {
                        bluetoothAdapter.cancelDiscovery();
                        bluetoothAdapter.startDiscovery();
                    } catch (Exception ignored) {
                    }
                }, 800);
            }
        } catch (SecurityException e) {
            tvStatus.setText("没有扫描权限（BLUETOOTH_SCAN）");
        } catch (Exception ignored) {
        }
    }

    private void startBleScan() {
        try {
            leScanner = bluetoothAdapter.getBluetoothLeScanner();
            if (leScanner == null) return;
            ScanSettings settings = new ScanSettings.Builder()
                    .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
                    .build();
            leScanner.startScan(null, settings, leCallback);
        } catch (SecurityException e) {
            // 无 BLUETOOTH_SCAN 权限
        } catch (Exception ignored) {
        }
    }

    private void stopBleScan() {
        try {
            if (leScanner != null) leScanner.stopScan(leCallback);
        } catch (Exception ignored) {
        }
    }

    private final ScanCallback leCallback = new ScanCallback() {
        @Override
        public void onScanResult(int callbackType, ScanResult result) {
            if (result == null || result.getDevice() == null) return;
            addOrUpdate(result.getDevice(), result.getRssi());
        }

        @Override
        public void onBatchScanResults(List<ScanResult> results) {
            if (results == null) return;
            for (ScanResult r : results) {
                if (r != null && r.getDevice() != null) addOrUpdate(r.getDevice(), r.getRssi());
            }
        }

        @Override
        public void onScanFailed(int errorCode) {
            // 扫描失败（常见于权限不足或被系统限流），不影响经典扫描
        }
    };

    private final BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (BluetoothDevice.ACTION_FOUND.equals(action)) {
                BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                int rssi = intent.getShortExtra(BluetoothDevice.EXTRA_RSSI, (short) -127);
                if (device != null) addOrUpdate(device, rssi);
            } else if (BluetoothDevice.ACTION_BOND_STATE_CHANGED.equals(action)) {
                BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                if (device != null) addOrUpdate(device, -127);
            } else if (BluetoothAdapter.ACTION_DISCOVERY_FINISHED.equals(action)) {
                // 每轮结束由定时器统一续扫，这里只更新提示，不再注销接收器
                if (!destroy) {
                    tvStatus.setText("本轮结束，已发现 " + deviceList.size() + " 个设备，继续扫描…");
                }
            }
        }
    };

    private void showBondedDevices() {
        try {
            Set<BluetoothDevice> bonded = bluetoothAdapter.getBondedDevices();
            if (bonded == null) return;
            for (BluetoothDevice d : bonded) addOrUpdate(d, -127);
        } catch (SecurityException e) {
            // 没有 BLUETOOTH_CONNECT 权限
        }
    }

    /** 结果合并去重：设备名可能为空（HC-06 常见），也要能显示 */
    private void addOrUpdate(BluetoothDevice device, int rssi) {
        if (device == null) return;
        String address = device.getAddress();
        if (address == null) return;
        Integer idx = indexByAddress.get(address);
        if (idx == null) {
            indexByAddress.put(address, deviceList.size());
            deviceList.add(device);
            deviceListAdapter.add(labelOf(device, rssi));
        } else {
            deviceList.set(idx, device);
            deviceListAdapter.remove(deviceListAdapter.getItem(idx));
            deviceListAdapter.insert(labelOf(device, rssi), idx);
        }
    }

    private String labelOf(BluetoothDevice device, int rssi) {
        String name = null;
        int type = BluetoothDevice.DEVICE_TYPE_UNKNOWN;
        int bond = BluetoothDevice.BOND_NONE;
        try {
            name = device.getName();
            type = device.getType();
            bond = device.getBondState();
        } catch (SecurityException ignored) {
        }
        if (TextUtils.isEmpty(name)) name = "未知设备";
        String typeText;
        if (type == BluetoothDevice.DEVICE_TYPE_LE) typeText = "BLE";
        else if (type == BluetoothDevice.DEVICE_TYPE_DUAL) typeText = "双模";
        else typeText = "经典";
        String bondText = (bond == BluetoothDevice.BOND_BONDED) ? "已配对" : "未配对";
        String rssiText = (rssi > -127 && rssi != 0) ? ("  RSSI " + rssi) : "";
        return name + "\n" + device.getAddress() + "   ·   " + typeText + "   ·   " + bondText + rssiText;
    }

    private void returnDevice(BluetoothDevice device) {
        int type = BluetoothDevice.DEVICE_TYPE_CLASSIC;
        try {
            type = device.getType();
        } catch (SecurityException ignored) {
        }
        Intent intent = new Intent();
        intent.putExtra("device_address", device.getAddress());
        intent.putExtra("device_type", type);
        setResult(RESULT_OK, intent);
        finish();
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onDestroy() {
        destroy = true;
        stopBleScan();
        handler.removeCallbacksAndMessages(null);
        try {
            if (bluetoothAdapter != null && bluetoothAdapter.isDiscovering()) {
                bluetoothAdapter.cancelDiscovery();
            }
        } catch (Exception ignored) {
        }
        if (receiverRegistered) {
            try {
                unregisterReceiver(receiver);
            } catch (IllegalArgumentException ignored) {
            }
            receiverRegistered = false;
        }
        super.onDestroy();
    }
}
