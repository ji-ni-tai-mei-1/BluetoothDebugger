package com.example.bluetoothdebugger;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.BluetoothSocket;
import android.content.Context;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.Method;
import java.util.UUID;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;

/**
 * 蓝牙连接服务：同时兼容经典 SPP 模块（HC-05/HC-06 等）与 BLE 串口模块（HC-08/HM-10/AT-09 等）。
 *
 * 针对"搜到但连不上 / 连接错误"的优化：
 *  1. 连接前强制 cancelDiscovery()（扫描过程中连接必失败，这是最常见的失败原因）；
 *  2. 经典连接依次尝试：安全 RFCOMM → 非安全 RFCOMM → 反射通道 1，每种最多 3 轮，失败间隔重试；
 *  3. 未配对时自动发起配对并等待用户输入 PIN（HC-06 默认 1234/0000），配对完成后再连一次；
 *  4. 经典方式全部失败、或设备本身就是 BLE 设备时，自动改用 BLE GATT 串口（FFE0/FFE1、Nordic UART 等）；
 *  5. 断线/失败都会给出更具体的原因，方便区分"没配对 / 没权限 / 不在范围"。
 */
public class BluetoothService {
    private static final String TAG = "BluetoothService";
    private static final UUID SPP_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    // BLE 串口常见服务/特征
    private static final UUID UUID_FFE0 = UUID.fromString("0000ffe0-0000-1000-8000-00805f9b34fb");
    private static final UUID UUID_FFE1 = UUID.fromString("0000ffe1-0000-1000-8000-00805f9b34fb");
    private static final UUID UUID_FFE5 = UUID.fromString("0000ffe5-0000-1000-8000-00805f9b34fb");
    private static final UUID UUID_FFE9 = UUID.fromString("0000ffe9-0000-1000-8000-00805f9b34fb");
    private static final UUID UUID_NUS_SERVICE = UUID.fromString("6e400001-b5a3-f393-e0a9-e50e24dcca9e");
    private static final UUID UUID_NUS_RX = UUID.fromString("6e400002-b5a3-f393-e0a9-e50e24dcca9e");
    private static final UUID UUID_NUS_TX = UUID.fromString("6e400003-b5a3-f393-e0a9-e50e24dcca9e");
    private static final UUID UUID_CCCD = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");

    private static final int BLE_MTU_PAYLOAD = 20;      // 未协商 MTU 时 BLE 单包有效载荷
    private static final long BLE_CONNECT_TIMEOUT_MS = 15000;

    // 单例：让蓝牙连接在 Activity 因横竖屏切换等配置变更而重建时得以保留
    private static volatile BluetoothService instance;

    public static BluetoothService getInstance() {
        if (instance == null) {
            synchronized (BluetoothService.class) {
                if (instance == null) {
                    instance = new BluetoothService();
                }
            }
        }
        return instance;
    }

    private BluetoothService() {
    }

    private Context appContext;
    private BluetoothSocket socket;
    private OutputStream outputStream;
    private InputStream inputStream;
    private ConnectThread connectThread;
    private ConnectedThread connectedThread;
    private ConnectionListener listener;

    // ===== BLE 相关 =====
    private volatile boolean bleMode = false;
    private BluetoothGatt gatt;
    private BluetoothGattCharacteristic bleWriteChar;
    private volatile boolean bleReady = false;
    private CountDownLatch bleLatch;
    private volatile String lastError = "";

    private final AtomicLong totalTxBytes = new AtomicLong(0);
    private final AtomicLong totalRxBytes = new AtomicLong(0);
    private long lastTxBytes = 0;
    private long lastRxBytes = 0;
    private long lastRateUpdateTime = 0;
    private int currentRate = 0;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    public interface ConnectionListener {
        void onConnected();
        void onDisconnected();
        void onConnectionFailed(String reason);
        void onDataReceived(byte[] data);
    }

    public void setConnectionListener(ConnectionListener listener) {
        this.listener = listener;
    }

    /** 推荐入口：传入 Context，BLE 兜底需要它 */
    public void connect(Context context, BluetoothDevice device) {
        if (context != null) {
            appContext = context.getApplicationContext();
        }
        connect(device);
    }

    public void connect(BluetoothDevice device) {
        disconnect();
        lastError = "";
        bleMode = false;
        bleReady = false;
        connectThread = new ConnectThread(device);
        connectThread.start();
    }

    public void disconnect() {
        if (connectedThread != null) {
            connectedThread.cancel();
            connectedThread = null;
        }
        if (connectThread != null) {
            connectThread.cancel();
            connectThread = null;
        }
        if (gatt != null) {
            try {
                gatt.disconnect();
            } catch (Exception ignored) {
            }
            try {
                gatt.close();
            } catch (Exception ignored) {
            }
            gatt = null;
        }
        bleWriteChar = null;
        bleReady = false;
        if (socket != null) {
            try {
                socket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            socket = null;
        }
        outputStream = null;
        inputStream = null;
        if (listener != null) {
            mainHandler.post(listener::onDisconnected);
        }
    }

    public boolean isConnected() {
        if (bleMode) return bleReady;
        return socket != null && socket.isConnected();
    }

    /** 当前是否走 BLE 通道（用于界面提示） */
    public boolean isBle() {
        return bleMode;
    }

    public void sendData(byte[] data) {
        if (data == null || data.length == 0) return;
        if (bleMode) {
            sendBle(data);
            return;
        }
        if (outputStream != null && isConnected()) {
            try {
                outputStream.write(data);
                totalTxBytes.addAndGet(data.length);
            } catch (IOException e) {
                Log.e(TAG, "Send failed", e);
                disconnect();
            }
        }
    }

    private void sendBle(byte[] data) {
        BluetoothGattCharacteristic ch = bleWriteChar;
        if (ch == null || gatt == null || !bleReady) return;
        int offset = 0;
        while (offset < data.length) {
            int len = Math.min(BLE_MTU_PAYLOAD, data.length - offset);
            byte[] chunk = new byte[len];
            System.arraycopy(data, offset, chunk, 0, len);
            offset += len;
            boolean ok = false;
            try {
                ch.setValue(chunk);
                ok = gatt.writeCharacteristic(ch);
            } catch (SecurityException e) {
                return;
            } catch (Exception e) {
                ok = false;
            }
            if (!ok) {
                // 有些模块只支持 NO_RESPONSE 写
                try {
                    ch.setWriteType(BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE);
                    ch.setValue(chunk);
                    ok = gatt.writeCharacteristic(ch);
                } catch (Exception ignored) {
                }
            }
            if (!ok) {
                return;
            }
            totalTxBytes.addAndGet(len);
            try {
                Thread.sleep(12);   // 给模块留出处理时间，避免连续写被丢
            } catch (InterruptedException ignored) {
            }
        }
    }

    public long getTotalTxBytes() {
        return totalTxBytes.get();
    }

    public long getTotalRxBytes() {
        return totalRxBytes.get();
    }

    public int getCurrentRate() {
        return currentRate;
    }

    public void updateRate() {
        long now = System.currentTimeMillis();
        if (lastRateUpdateTime == 0) {
            lastRateUpdateTime = now;
            lastTxBytes = totalTxBytes.get();
            lastRxBytes = totalRxBytes.get();
            currentRate = 0;
            return;
        }
        long elapsed = now - lastRateUpdateTime;
        if (elapsed >= 1000) {
            long newTx = totalTxBytes.get();
            long newRx = totalRxBytes.get();
            long deltaTx = newTx - lastTxBytes;
            long deltaRx = newRx - lastRxBytes;
            currentRate = (int) (deltaTx + deltaRx);
            lastTxBytes = newTx;
            lastRxBytes = newRx;
            lastRateUpdateTime = now;
        }
    }

    // =====================================================================
    // 连接线程
    // =====================================================================
    private class ConnectThread extends Thread {
        private final BluetoothDevice device;

        ConnectThread(BluetoothDevice device) {
            this.device = device;
        }

        public void run() {
            cancelDiscovery();
            int type = deviceType(device);
            boolean classicOk = false;

            if (type != BluetoothDevice.DEVICE_TYPE_LE) {
                classicOk = tryClassicConnect(device);
                if (!classicOk && bondState(device) != BluetoothDevice.BOND_BONDED) {
                    // 未配对：发起系统配对（HC-06 需要输入 PIN，默认 1234/0000），配对成功后再连一次
                    if (ensureBonded(device)) {
                        classicOk = tryClassicConnect(device);
                    }
                }
            }

            if (!classicOk) {
                // 经典失败（或本来就是 BLE 模块）→ BLE 串口兜底
                bleMode = true;
                if (!tryBleConnect(device)) {
                    bleMode = false;
                    String reason = lastError.isEmpty()
                            ? "连接失败：模块可能未上电/不在范围内，或需要先在系统蓝牙里配对（HC-06 默认 PIN 1234 或 0000）"
                            : lastError;
                    if (listener != null) {
                        mainHandler.post(() -> listener.onConnectionFailed(reason));
                    }
                    closeQuietly();
                    return;
                }
            }

            if (listener != null) {
                mainHandler.post(listener::onConnected);
            }
        }

        public void cancel() {
            try {
                if (socket != null) socket.close();
            } catch (IOException ignored) {
            }
        }
    }

    private void cancelDiscovery() {
        try {
            BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
            if (adapter != null && adapter.isDiscovering()) {
                adapter.cancelDiscovery();
                Thread.sleep(300);   // 等扫描真正停下再连，否则必失败
            }
        } catch (Exception ignored) {
        }
    }

    private int deviceType(BluetoothDevice device) {
        try {
            return device.getType();
        } catch (SecurityException e) {
            return BluetoothDevice.DEVICE_TYPE_CLASSIC;
        } catch (Exception e) {
            return BluetoothDevice.DEVICE_TYPE_CLASSIC;
        }
    }

    private int bondState(BluetoothDevice device) {
        try {
            return device.getBondState();
        } catch (Exception e) {
            return BluetoothDevice.BOND_NONE;
        }
    }

    /** 需要的 PIN 由系统弹窗输入；这里只等待配对结果 */
    private boolean ensureBonded(BluetoothDevice device) {
        try {
            if (!device.createBond()) {
                // createBond 返回 false 时可能已经在配对中，继续等待
            }
            for (int i = 0; i < 24; i++) {   // 最多等 ~12s
                int state = bondState(device);
                if (state == BluetoothDevice.BOND_BONDED) return true;
                if (state == BluetoothDevice.BOND_NONE && i > 8) return false;
                Thread.sleep(500);
            }
        } catch (SecurityException e) {
            lastError = "缺少蓝牙连接权限（BLUETOOTH_CONNECT），请在系统设置里允许";
        } catch (Exception ignored) {
        }
        return bondState(device) == BluetoothDevice.BOND_BONDED;
    }

    // =====================================================================
    // 经典 SPP：安全 → 非安全 → 反射通道，多轮重试
    // =====================================================================
    private boolean tryClassicConnect(BluetoothDevice device) {
        for (int attempt = 1; attempt <= 3; attempt++) {
            BluetoothSocket s = null;
            try {
                if (attempt == 1) {
                    s = device.createRfcommSocketToServiceRecord(SPP_UUID);
                } else if (attempt == 2) {
                    s = device.createInsecureRfcommSocketToServiceRecord(SPP_UUID);
                } else {
                    s = createRfcommSocketByReflection(device);
                }
                if (s == null) continue;
                s.connect();
                socket = s;
                bleMode = false;
                outputStream = socket.getOutputStream();
                inputStream = socket.getInputStream();
                connectedThread = new ConnectedThread();
                connectedThread.start();
                return true;
            } catch (SecurityException e) {
                lastError = "缺少蓝牙连接权限（BLUETOOTH_CONNECT）";
                closeQuietly(s);
                return false;
            } catch (Exception e) {
                lastError = "经典连接失败：" + e.getClass().getSimpleName()
                        + (e.getMessage() == null ? "" : (" " + e.getMessage()));
                closeQuietly(s);
                try {
                    Thread.sleep(600);
                } catch (InterruptedException ignored) {
                }
            }
        }
        return false;
    }

    /** 某些模块（老 HC-05/06 固件）只有固定 RFCOMM 通道 1 可用，用反射兜底 */
    private BluetoothSocket createRfcommSocketByReflection(BluetoothDevice device) {
        try {
            Method m = device.getClass().getMethod("createRfcommSocket", int.class);
            return (BluetoothSocket) m.invoke(device, 1);
        } catch (Exception e) {
            return null;
        }
    }

    // =====================================================================
    // BLE GATT 串口（HC-08 / HM-10 / AT-09 / Nordic UART）
    // =====================================================================
    private boolean tryBleConnect(BluetoothDevice device) {
        if (appContext == null) {
            lastError = "BLE 连接缺少 Context";
            return false;
        }
        bleLatch = new CountDownLatch(1);
        try {
            gatt = device.connectGatt(appContext, false, gattCallback, BluetoothDevice.TRANSPORT_LE);
        } catch (SecurityException e) {
            lastError = "缺少蓝牙连接权限（BLUETOOTH_CONNECT）";
            return false;
        } catch (Exception e) {
            lastError = "BLE 连接发起失败：" + e.getMessage();
            return false;
        }
        if (gatt == null) {
            lastError = "BLE 连接发起失败（connectGatt 返回空）";
            return false;
        }
        try {
            boolean done = bleLatch.await(BLE_CONNECT_TIMEOUT_MS, TimeUnit.MILLISECONDS);
            if (!done || bleWriteChar == null) {
                if (lastError.isEmpty()) lastError = "BLE 连接超时：模块可能不在范围内，或不是 BLE 串口模块";
                closeQuietly();
                return false;
            }
        } catch (InterruptedException e) {
            lastError = "BLE 连接被中断";
            closeQuietly();
            return false;
        }
        bleReady = true;
        return true;
    }

    private final BluetoothGattCallback gattCallback = new BluetoothGattCallback() {
        @Override
        public void onConnectionStateChange(BluetoothGatt g, int status, int newState) {
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                try {
                    g.discoverServices();
                } catch (Exception e) {
                    lastError = "BLE 服务发现失败";
                    bleLatch.countDown();
                }
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                bleReady = false;
                if (bleLatch != null && bleLatch.getCount() > 0) {
                    if (status != 0) lastError = "BLE 连接被拒绝（status=" + status + "）";
                    bleLatch.countDown();   // 连接阶段失败
                } else if (isConnected() || bleMode) {
                    if (listener != null) mainHandler.post(listener::onDisconnected);
                }
            }
        }

        @Override
        public void onServicesDiscovered(BluetoothGatt g, int status) {
            if (status != BluetoothGatt.GATT_SUCCESS) {
                lastError = "BLE 服务发现失败（status=" + status + "）";
                bleLatch.countDown();
                return;
            }
            BluetoothGattCharacteristic notifyChar = null;
            BluetoothGattCharacteristic writeChar = null;

            for (BluetoothGattService service : g.getServices()) {
                UUID su = service.getUuid();
                for (BluetoothGattCharacteristic c : service.getCharacteristics()) {
                    UUID cu = c.getUuid();
                    // 已知串口特征优先
                    if (cu.equals(UUID_FFE1) || cu.equals(UUID_FFE9) || cu.equals(UUID_NUS_TX)) {
                        notifyChar = c;
                        if (cu.equals(UUID_FFE1) || cu.equals(UUID_FFE9)) writeChar = c;
                    }
                    if (cu.equals(UUID_NUS_RX)) writeChar = c;
                    if (su.equals(UUID_FFE0) || su.equals(UUID_FFE5) || su.equals(UUID_NUS_SERVICE)) {
                        int props = c.getProperties();
                        boolean canWrite = (props & (BluetoothGattCharacteristic.PROPERTY_WRITE
                                | BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE)) != 0;
                        boolean canNotify = (props & (BluetoothGattCharacteristic.PROPERTY_NOTIFY
                                | BluetoothGattCharacteristic.PROPERTY_INDICATE)) != 0;
                        if (writeChar == null && canWrite) writeChar = c;
                        if (notifyChar == null && canNotify) notifyChar = c;
                    }
                }
            }
            if (writeChar == null) {
                // 通用兜底：任意可写特征
                for (BluetoothGattService service : g.getServices()) {
                    for (BluetoothGattCharacteristic c : service.getCharacteristics()) {
                        int props = c.getProperties();
                        if ((props & (BluetoothGattCharacteristic.PROPERTY_WRITE
                                | BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE)) != 0) {
                            writeChar = c;
                            break;
                        }
                    }
                    if (writeChar != null) break;
                }
            }
            if (writeChar == null) {
                lastError = "BLE 模块没有可写特征（可能不是串口透传模块）";
                bleLatch.countDown();
                return;
            }
            bleWriteChar = writeChar;
            if (notifyChar != null) enableNotify(g, notifyChar);
            bleLatch.countDown();
        }

        @Override
        public void onCharacteristicChanged(BluetoothGatt g, BluetoothGattCharacteristic c) {
            byte[] value = c.getValue();
            dispatchRx(value);
        }

        @Override
        public void onCharacteristicChanged(BluetoothGatt g, BluetoothGattCharacteristic c, byte[] value) {
            dispatchRx(value);
        }
    };

    private void enableNotify(BluetoothGatt g, BluetoothGattCharacteristic c) {
        try {
            g.setCharacteristicNotification(c, true);
            BluetoothGattDescriptor desc = c.getDescriptor(UUID_CCCD);
            if (desc != null) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    g.writeDescriptor(desc, BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
                } else {
                    desc.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
                    g.writeDescriptor(desc);
                }
            }
        } catch (Exception ignored) {
        }
    }

    private void dispatchRx(byte[] value) {
        if (value == null || value.length == 0) return;
        totalRxBytes.addAndGet(value.length);
        byte[] data = new byte[value.length];
        System.arraycopy(value, 0, data, 0, value.length);
        if (listener != null) {
            mainHandler.post(() -> listener.onDataReceived(data));
        }
    }

    private void closeQuietly() {
        closeQuietly(socket);
        socket = null;
        outputStream = null;
        inputStream = null;
        if (gatt != null) {
            try {
                gatt.close();
            } catch (Exception ignored) {
            }
            gatt = null;
        }
    }

    private void closeQuietly(BluetoothSocket s) {
        if (s == null) return;
        try {
            s.close();
        } catch (IOException ignored) {
        }
    }

    // =====================================================================
    // 接收线程（经典 SPP）
    // =====================================================================
    private class ConnectedThread extends Thread {
        public void run() {
            byte[] buffer = new byte[1024];
            int bytes;
            while (true) {
                try {
                    InputStream in = inputStream;
                    if (in == null) break;
                    bytes = in.read(buffer);
                    if (bytes > 0) {
                        totalRxBytes.addAndGet(bytes);
                        byte[] data = new byte[bytes];
                        System.arraycopy(buffer, 0, data, 0, bytes);
                        if (listener != null) {
                            mainHandler.post(() -> listener.onDataReceived(data));
                        }
                    }
                } catch (IOException e) {
                    Log.e(TAG, "Disconnected", e);
                    disconnect();
                    break;
                }
            }
        }

        public void cancel() {
            try {
                if (socket != null) socket.close();
            } catch (IOException ignored) {
            }
        }
    }
}
