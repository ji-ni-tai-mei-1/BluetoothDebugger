package com.example.bluetoothdebugger;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

/**
 * 首页：列出已保存的工程视图（横/竖屏），支持创建与删除。
 * 点某个工程进入调试操控界面（MainActivity），方向在创建时已定死，进入后不可修改。
 */
public class HomeActivity extends AppCompatActivity {

    private LinearLayout listContainer;
    private TextView tvEmpty;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        listContainer = findViewById(R.id.listContainer);
        tvEmpty = findViewById(R.id.tvEmpty);
        Button btnCreate = findViewById(R.id.btnCreateProject);
        Button btnDelete = findViewById(R.id.btnDeleteProject);

        btnCreate.setOnClickListener(v -> showCreateDialog());
        btnDelete.setOnClickListener(v -> showDeleteDialog());

        refreshList();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshList();   // 从调试界面返回后立即刷新工程列表
    }

    private void refreshList() {
        listContainer.removeAllViews();
        List<ProjectStore.Project> projects = ProjectStore.loadAll(this);
        tvEmpty.setVisibility(projects.isEmpty() ? View.VISIBLE : View.GONE);
        for (ProjectStore.Project p : projects) {
            listContainer.addView(buildRow(p));
        }
    }

    private View buildRow(final ProjectStore.Project p) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(12), dp(12), dp(12), dp(12));
        LinearLayout.LayoutParams rl = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        rl.bottomMargin = dp(8);
        row.setLayoutParams(rl);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.argb(45, 0, 0, 0));
        bg.setCornerRadius(dp(10));
        row.setBackground(bg);

        TextView name = new TextView(this);
        name.setText(p.name);
        name.setTextSize(16);
        name.setTextColor(Color.BLACK);
        name.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView tag = new TextView(this);
        tag.setText(p.landscape ? "横屏" : "竖屏");
        tag.setTextSize(12);
        tag.setTextColor(p.landscape ? Color.rgb(0, 110, 190) : Color.rgb(180, 120, 0));
        tag.setPadding(dp(8), dp(2), dp(8), dp(2));
        GradientDrawable tagBg = new GradientDrawable();
        tagBg.setColor(Color.argb(30, 0, 0, 0));
        tagBg.setCornerRadius(dp(8));
        tag.setBackground(tagBg);

        row.addView(name);
        row.addView(tag);
        row.setOnClickListener(v -> {
            Intent intent = new Intent(this, MainActivity.class);
            intent.putExtra(MainActivity.EXTRA_PROJECT, p.name);
            startActivity(intent);
        });
        return row;
    }

    private void showCreateDialog() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(8), dp(20), 0);

        EditText etName = new EditText(this);
        etName.setHint("请输入工程名称");
        box.addView(etName);

        TextView tvDir = new TextView(this);
        tvDir.setText("选择显示方向（创建后不可更改）：");
        tvDir.setTextSize(14);
        tvDir.setPadding(0, dp(16), 0, dp(6));
        box.addView(tvDir);

        RadioGroup group = new RadioGroup(this);
        group.setOrientation(RadioGroup.HORIZONTAL);
        RadioButton rbLand = new RadioButton(this);
        rbLand.setText("横屏");
        RadioButton rbPort = new RadioButton(this);
        rbPort.setText("竖屏");
        // 必须给每个 RadioButton 独立 id，RadioGroup 才能保证互斥单选
        int idLand = View.generateViewId();
        int idPort = View.generateViewId();
        rbLand.setId(idLand);
        rbPort.setId(idPort);
        group.addView(rbLand);
        group.addView(rbPort);
        group.check(idLand);
        box.addView(group);

        new AlertDialog.Builder(this)
                .setTitle("创建工程视图")
                .setView(box)
                .setPositiveButton("创建并进入", (d, w) -> {
                    String name = etName.getText().toString().trim();
                    if (name.isEmpty()) {
                        Toast.makeText(this, "请先输入工程名称", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    boolean landscape = group.getCheckedRadioButtonId() == idLand;
                    for (ProjectStore.Project exist : ProjectStore.loadAll(this)) {
                        if (exist.name.equals(name)) {
                            Toast.makeText(this, "已存在同名工程：" + name, Toast.LENGTH_SHORT).show();
                            return;
                        }
                    }
                    ProjectStore.Project p = new ProjectStore.Project(name, landscape);
                    ProjectStore.addNewProjectItems(p);
                    ProjectStore.save(this, p);
                    refreshList();
                    Intent intent = new Intent(this, MainActivity.class);
                    intent.putExtra(MainActivity.EXTRA_PROJECT, name);
                    startActivity(intent);
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private void showDeleteDialog() {
        List<ProjectStore.Project> projects = ProjectStore.loadAll(this);
        if (projects.isEmpty()) {
            Toast.makeText(this, "没有可删除的工程视图", Toast.LENGTH_SHORT).show();
            return;
        }
        String[] labels = new String[projects.size()];
        for (int i = 0; i < projects.size(); i++) {
            labels[i] = projects.get(i).name + "（" + (projects.get(i).landscape ? "横屏" : "竖屏") + "）";
        }
        new AlertDialog.Builder(this)
                .setTitle("选择要删除的工程视图")
                .setItems(labels, (d, which) -> {
                    ProjectStore.Project p = projects.get(which);
                    new AlertDialog.Builder(this)
                            .setTitle("删除工程视图")
                            .setMessage("确定删除 \"" + p.name + "\" 吗？该工程内所有控件配置将一并删除。")
                            .setPositiveButton("删除", (d2, w2) -> {
                                ProjectStore.delete(this, p.name);
                                refreshList();
                            })
                            .setNegativeButton("取消", null)
                            .show();
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }
}
