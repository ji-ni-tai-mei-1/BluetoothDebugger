package com.example.bluetoothdebugger;

import android.app.AlertDialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;

public class RangeSettingDialog {
    public static class Settings {
        public int joy1XMin, joy1XMax;
        public int joy1YMin, joy1YMax;
        public int joy2XMin, joy2XMax;

        public Settings() {
            // 默认范围 -90 ~ 90
            joy1XMin = -90; joy1XMax = 90;
            joy1YMin = -90; joy1YMax = 90;
            joy2XMin = -90; joy2XMax = 90;
        }
    }

    public interface OnSettingsSavedListener {
        void onSaved(Settings settings);
    }

    public static void show(Context context, Settings currentSettings, OnSettingsSavedListener listener) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        View view = LayoutInflater.from(context).inflate(R.layout.dialog_range_settings, null);
        builder.setView(view);
        builder.setTitle("摇杆范围设置");

        EditText etJoy1XMin = view.findViewById(R.id.etJoy1XMin);
        EditText etJoy1XMax = view.findViewById(R.id.etJoy1XMax);
        EditText etJoy1YMin = view.findViewById(R.id.etJoy1YMin);
        EditText etJoy1YMax = view.findViewById(R.id.etJoy1YMax);
        EditText etJoy2XMin = view.findViewById(R.id.etJoy2XMin);
        EditText etJoy2XMax = view.findViewById(R.id.etJoy2XMax);

        // 填充当前值
        etJoy1XMin.setText(String.valueOf(currentSettings.joy1XMin));
        etJoy1XMax.setText(String.valueOf(currentSettings.joy1XMax));
        etJoy1YMin.setText(String.valueOf(currentSettings.joy1YMin));
        etJoy1YMax.setText(String.valueOf(currentSettings.joy1YMax));
        etJoy2XMin.setText(String.valueOf(currentSettings.joy2XMin));
        etJoy2XMax.setText(String.valueOf(currentSettings.joy2XMax));

        builder.setPositiveButton("保存", (dialog, which) -> {
            Settings newSettings = new Settings();
            try {
                newSettings.joy1XMin = Integer.parseInt(etJoy1XMin.getText().toString());
                newSettings.joy1XMax = Integer.parseInt(etJoy1XMax.getText().toString());
                newSettings.joy1YMin = Integer.parseInt(etJoy1YMin.getText().toString());
                newSettings.joy1YMax = Integer.parseInt(etJoy1YMax.getText().toString());
                newSettings.joy2XMin = Integer.parseInt(etJoy2XMin.getText().toString());
                newSettings.joy2XMax = Integer.parseInt(etJoy2XMax.getText().toString());
                listener.onSaved(newSettings);
            } catch (NumberFormatException e) {
                // 忽略错误，保留原值
            }
        });
        builder.setNegativeButton("取消", null);
        builder.show();
    }
}