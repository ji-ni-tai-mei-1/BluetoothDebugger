package com.example.bluetoothdebugger;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.nio.ByteBuffer;

public class MainActivity extends AppCompatActivity {
    private static final int REQUEST_ENABLE_BT = 1;
    private static final int REQUEST_SELECT_DEVICE = 2;
    private static final int PERMISSION_REQUEST_CODE = 100;

    private TextView tvStatus, tvTx, tvRx, tvRate, tvJoy1X, tvJoy1Y, tvJoy2X;
    private Button btnConnect, btnSettings;
    private JoystickView joystick1, joystick2;

    private BluetoothService bluetoothService;
    private BluetoothAdapter bluetoothAdapter;
    private Handler mainHandler = new Handler(Looper.getMainLooper());
    private Runnable rateUpdater;

    private RangeSettingDialog.Settings settings = new RangeSettingDialog.Settings();
    private float joy1X = 0f, joy1Y = 0f;
    private float joy2X = 0f;   // J2只使用X轴

    private long lastSendTime = 0;
    private static final long SEND_DELAY_MS = 50;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 初始化UI
        tvStatus = findViewById(R.id.tvConnectionStatus);
        tvTx = findViewById(R.id.tvTxBytes);
        tvRx = findViewById(R.id.tvRxBytes);
        tvRate = findViewById(R.id.tvRate);
        tvJoy1X = findViewById(R.id.tvJoy1X);
        tvJoy1Y = findViewById(R.id.tvJoy1Y);
        tvJoy2X = findViewById(R.id.tvJoy2X);
        btnConnect = findViewById(R.id.btnConnect);
        btnSettings = findViewById(R.id.btnSettings);
        joystick1 = findViewById(R.id.joystick1);
        joystick2 = findViewById(R.id.joystick2);

        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        if (bluetoothAdapter == null) {
            Toast.makeText(this, "设备不支持蓝牙", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        bluetoothService = new BluetoothService();
        bluetoothService.setConnectionListener(new BluetoothService.ConnectionListener() {
            @Override
            public void onConnected() {
                runOnUiThread(() -> {
                    tvStatus.setText("已连接");
                    tvStatus.setTextColor(ContextCompat.getColor(MainActivity.this, android.R.color.holo_green_dark));
                });
            }

            @Override
            public void onDisconnected() {
                runOnUiThread(() -> {
                    tvStatus.setText("未连接");
                    tvStatus.setTextColor(ContextCompat.getColor(MainActivity.this, android.R.color.holo_red_dark));
                });
            }

            @Override
            public void onConnectionFailed(String reason) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "连接失败: " + reason, Toast.LENGTH_SHORT).show());
            }
        });

        checkPermissionsAndEnableBluetooth();
        setupControls();

        rateUpdater = new Runnable() {
            @Override
            public void run() {
                bluetoothService.updateRate();
                tvTx.setText("TX: " + bluetoothService.getTotalTxBytes());
                tvRx.setText("RX: " + bluetoothService.getTotalRxBytes());
                tvRate.setText("速率: " + bluetoothService.getCurrentRate() + " B/s");
                mainHandler.postDelayed(this, 1000);
            }
        };
        mainHandler.post(rateUpdater);
    }

    private void setupControls() {
        // 摇杆1（输出 X 和 Y）
        joystick1.setOnJoystickMoveListener((x, y) -> {
            joy1X = x;
            joy1Y = y;
            tvJoy1X.setText(String.format("J1 X: %.2f", x));
            tvJoy1Y.setText(String.format("J1 Y: %.2f", y));
            sendPacketDelayed();
        });

        // 摇杆2（只输出 X 轴，Y轴忽略）
        joystick2.setOnJoystickMoveListener((x, y) -> {
            joy2X = x;
            tvJoy2X.setText(String.format("J2 X: %.2f", x));
            sendPacketDelayed();
        });

        // 连接设备
        btnConnect.setOnClickListener(v -> {
            if (bluetoothService.isConnected()) {
                bluetoothService.disconnect();
            } else {
                if (!bluetoothAdapter.isEnabled()) {
                    Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                    startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
                } else {
                    Intent intent = new Intent(MainActivity.this, DeviceListActivity.class);
                    startActivityForResult(intent, REQUEST_SELECT_DEVICE);
                }
            }
        });

        // 设置对话框
        btnSettings.setOnClickListener(v -> {
            RangeSettingDialog.show(MainActivity.this, settings, newSettings -> {
                settings = newSettings;
                sendPacketNow();
            });
        });
    }

    private void sendPacketDelayed() {
        long now = System.currentTimeMillis();
        if (now - lastSendTime >= SEND_DELAY_MS) {
            sendPacketNow();
            lastSendTime = now;
        } else {
            mainHandler.removeCallbacks(delayedSend);
            mainHandler.postDelayed(delayedSend, SEND_DELAY_MS);
        }
    }

    private Runnable delayedSend = this::sendPacketNow;

    private void sendPacketNow() {
        if (!bluetoothService.isConnected()) return;

        // 将归一化值映射到用户设置的物理范围（默认 -90 ~ 90）
        int j1y = mapRange(joy1Y, -1f, 1f, settings.joy1YMin, settings.joy1YMax);
        int j1x = mapRange(joy1X, -1f, 1f, settings.joy1XMin, settings.joy1XMax);
        int j2x = mapRange(joy2X, -1f, 1f, settings.joy2XMin, settings.joy2XMax);

        // 转换为 byte（有符号8位）
        byte bJ1Y = (byte) j1y;
        byte bJ1X = (byte) j1x;
        byte bJ2X = (byte) j2x;

        // 数据包: 0xA5 + J1Y + J1X + J2X + 0x5A
        ByteBuffer buffer = ByteBuffer.allocate(5);
        buffer.put((byte) 0xA5);
        buffer.put(bJ1Y);
        buffer.put(bJ1X);
        buffer.put(bJ2X);
        buffer.put((byte) 0x5A);

        bluetoothService.sendData(buffer.array());
    }

    private int mapRange(float value, float fromLow, float fromHigh, int toLow, int toHigh) {
        return (int) (toLow + (value - fromLow) * (toHigh - toLow) / (fromHigh - fromLow));
    }

    // ---------- 权限处理（保持不变）----------
    private void checkPermissionsAndEnableBluetooth() {
        String[] permissions;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            permissions = new String[]{
                    Manifest.permission.BLUETOOTH_SCAN,
                    Manifest.permission.BLUETOOTH_CONNECT,
                    Manifest.permission.ACCESS_FINE_LOCATION
            };
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            permissions = new String[]{
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
            };
        } else {
            permissions = new String[]{};
        }

        boolean allGranted = true;
        for (String perm : permissions) {
            if (ContextCompat.checkSelfPermission(this, perm) != PackageManager.PERMISSION_GRANTED) {
                allGranted = false;
                break;
            }
        }
        if (!allGranted) {
            ActivityCompat.requestPermissions(this, permissions, PERMISSION_REQUEST_CODE);
        } else {
            if (!bluetoothAdapter.isEnabled()) {
                Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_CODE) {
            for (int result : grantResults) {
                if (result != PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(this, "需要必要权限才能使用蓝牙", Toast.LENGTH_SHORT).show();
                    finish();
                    return;
                }
            }
            if (!bluetoothAdapter.isEnabled()) {
                Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_SELECT_DEVICE && resultCode == RESULT_OK) {
            String address = data.getStringExtra("device_address");
            BluetoothDevice device = bluetoothAdapter.getRemoteDevice(address);
            bluetoothService.connect(device);
        } else if (requestCode == REQUEST_ENABLE_BT) {
            if (resultCode == RESULT_OK) {
                Toast.makeText(this, "蓝牙已开启", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "需要蓝牙才能工作", Toast.LENGTH_SHORT).show();
                finish();
            }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        bluetoothService.disconnect();
        mainHandler.removeCallbacks(rateUpdater);
        mainHandler.removeCallbacks(delayedSend);
    }
}