package com.example.bluetoothdebugger;

import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicLong;

public class BluetoothService {
    private static final String TAG = "BluetoothService";
    private static final UUID SPP_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    private BluetoothSocket socket;
    private OutputStream outputStream;
    private InputStream inputStream;
    private ConnectThread connectThread;
    private ConnectedThread connectedThread;
    private ConnectionListener listener;

    private AtomicLong totalTxBytes = new AtomicLong(0);
    private AtomicLong totalRxBytes = new AtomicLong(0);
    private long lastTxBytes = 0;
    private long lastRxBytes = 0;
    private long lastRateUpdateTime = 0;
    private int currentRate = 0;
    private Handler mainHandler = new Handler(Looper.getMainLooper());

    public interface ConnectionListener {
        void onConnected();
        void onDisconnected();
        void onConnectionFailed(String reason);
    }

    public void setConnectionListener(ConnectionListener listener) {
        this.listener = listener;
    }

    public void connect(BluetoothDevice device) {
        disconnect();
        connectThread = new ConnectThread(device);
        connectThread.start();
    }

    public void disconnect() {
        if (connectedThread != null) {
            connectedThread.cancel();
            connectedThread = null;
        }
        if (connectThread != null) {
            connectThread.cancel();
            connectThread = null;
        }
        if (socket != null) {
            try {
                socket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            socket = null;
        }
        outputStream = null;
        inputStream = null;
        if (listener != null) {
            mainHandler.post(listener::onDisconnected);
        }
    }

    public boolean isConnected() {
        return socket != null && socket.isConnected();
    }

    public void sendData(byte[] data) {
        if (outputStream != null && isConnected()) {
            try {
                outputStream.write(data);
                totalTxBytes.addAndGet(data.length);
            } catch (IOException e) {
                Log.e(TAG, "Send failed", e);
                disconnect();
            }
        }
    }

    public long getTotalTxBytes() {
        return totalTxBytes.get();
    }

    public long getTotalRxBytes() {
        return totalRxBytes.get();
    }

    public int getCurrentRate() {
        return currentRate;
    }

    public void updateRate() {
        long now = System.currentTimeMillis();
        if (lastRateUpdateTime == 0) {
            lastRateUpdateTime = now;
            lastTxBytes = totalTxBytes.get();
            lastRxBytes = totalRxBytes.get();
            currentRate = 0;
            return;
        }
        long elapsed = now - lastRateUpdateTime;
        if (elapsed >= 1000) {
            long newTx = totalTxBytes.get();
            long newRx = totalRxBytes.get();
            long deltaTx = newTx - lastTxBytes;
            long deltaRx = newRx - lastRxBytes;
            currentRate = (int) (deltaTx + deltaRx);
            lastTxBytes = newTx;
            lastRxBytes = newRx;
            lastRateUpdateTime = now;
        }
    }

    private class ConnectThread extends Thread {
        private final BluetoothDevice device;

        ConnectThread(BluetoothDevice device) {
            this.device = device;
        }

        public void run() {
            try {
                socket = device.createRfcommSocketToServiceRecord(SPP_UUID);
                socket.connect();
                outputStream = socket.getOutputStream();
                inputStream = socket.getInputStream();
                connectedThread = new ConnectedThread();
                connectedThread.start();
                if (listener != null) {
                    mainHandler.post(listener::onConnected);
                }
            } catch (IOException e) {
                Log.e(TAG, "Connection failed", e);
                disconnect();
                if (listener != null) {
                    mainHandler.post(() -> listener.onConnectionFailed(e.getMessage()));
                }
            }
        }

        public void cancel() {
            try {
                if (socket != null) socket.close();
            } catch (IOException e) {
            }
        }
    }

    private class ConnectedThread extends Thread {
        public void run() {
            byte[] buffer = new byte[1024];
            int bytes;
            while (true) {
                try {
                    bytes = inputStream.read(buffer);
                    if (bytes > 0) {
                        totalRxBytes.addAndGet(bytes);
                    }
                } catch (IOException e) {
                    Log.e(TAG, "Disconnected", e);
                    disconnect();
                    break;
                }
            }
        }

        public void cancel() {
            try {
                if (socket != null) socket.close();
            } catch (IOException e) {
            }
        }
    }
}