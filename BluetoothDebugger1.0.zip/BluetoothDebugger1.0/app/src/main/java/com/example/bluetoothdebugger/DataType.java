package com.example.bluetoothdebugger;

public enum DataType {
    UINT8(1),
    INT8(1),
    UINT16(2),
    INT16(2),
    FLOAT32(4);

    private final int byteLength;

    DataType(int byteLength) {
        this.byteLength = byteLength;
    }

    public int getByteLength() {
        return byteLength;
    }
}