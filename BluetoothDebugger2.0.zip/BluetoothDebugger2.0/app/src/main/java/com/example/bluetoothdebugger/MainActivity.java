package com.example.bluetoothdebugger;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.method.ScrollingMovementMethod;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    private static final int REQUEST_ENABLE_BT = 1;
    private static final int REQUEST_SELECT_DEVICE = 2;
    private static final int PERMISSION_REQUEST_CODE = 100;
    private static final int REQUEST_OVERLAY_PERMISSION = 1000;

    // UI 控件
    private TextView tvStatus, tvTx, tvRx, tvRate;
    private TextView tvJoy1X, tvJoy1Y, tvJoy2X, tvJoy2Y, tvSeekValue;
    private Button btnConnect;
    private SeekBar seekBar;
    private ToggleSwitch toggleSwitch;
    private JoystickView joystick1, joystick2;
    private FrameLayout btnRangeModeContainer;
    private Button btnOrientationSwitch;

    private BluetoothService bluetoothService;
    private BluetoothAdapter bluetoothAdapter;

    private RangeSettingDialog.Settings settings = new RangeSettingDialog.Settings();

    private float joy1X = 0f, joy1Y = 0f;
    private float joy2X = 0f, joy2Y = 0f;
    private int currentSeekValue = 0;
    private boolean buttonPressed = false;

    private long lastSendTime = 0;
    private static final long SEND_DELAY_MS = 50;
    private Handler mainHandler = new Handler(Looper.getMainLooper());
    private Runnable rateUpdater;
    private Runnable delayedSend = this::sendPacketNow;

    private boolean isSettingMode = false;

    // 悬浮窗相关
    private WindowManager windowManager;
    private View floatingView;
    private TextView tvFloatingData;
    private Button btnCollapse, btnExpand, btnFullscreen;
    private LinearLayout floatingTitleBar;
    private Button btnExpandFromCollapsed;
    private WindowManager.LayoutParams floatingParams;
    private List<String> receivedMessages = new ArrayList<>();
    private static final int MAX_MESSAGES = 100;
    private final SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm:ss", Locale.getDefault());

    private enum FloatState { EXPANDED, COLLAPSED, FULLSCREEN }
    private FloatState currentState = FloatState.EXPANDED;
    private int expandedWidth, expandedHeight;
    private int collapsedSize;
    private int fullscreenWidth, fullscreenHeight;
    private int joyDiameter;
    private int originalX, originalY;

    // 收起状态长按拖动相关变量
    private float collapsedDragStartX, collapsedDragStartY;
    private int collapsedStartPosX, collapsedStartPosY;
    private boolean isCollapsedDragging = false;
    private boolean hasMovedInCollapsed = false;

    private static final String KEY_SETTINGS = "settings";
    private static final String KEY_JOY1X = "joy1x";
    private static final String KEY_JOY1Y = "joy1y";
    private static final String KEY_JOY2X = "joy2x";
    private static final String KEY_JOY2Y = "joy2y";
    private static final String KEY_SEEK = "seek";
    private static final String KEY_BUTTON = "button";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        applyFullscreen();

        initViews();
        addRangeModeButton();
        addOrientationSwitchButton();

        btnConnect.setBackgroundColor(Color.argb(102, 255, 0, 0));

        if (savedInstanceState != null) {
            settings = (RangeSettingDialog.Settings) savedInstanceState.getSerializable(KEY_SETTINGS);
            joy1X = savedInstanceState.getFloat(KEY_JOY1X);
            joy1Y = savedInstanceState.getFloat(KEY_JOY1Y);
            joy2X = savedInstanceState.getFloat(KEY_JOY2X);
            joy2Y = savedInstanceState.getFloat(KEY_JOY2Y);
            currentSeekValue = savedInstanceState.getInt(KEY_SEEK);
            buttonPressed = savedInstanceState.getBoolean(KEY_BUTTON);
        }

        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        if (bluetoothAdapter == null) {
            Toast.makeText(this, "设备不支持蓝牙", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        bluetoothService = BluetoothService.getInstance();
        bluetoothService.setConnectionListener(new BluetoothService.ConnectionListener() {
            @Override
            public void onConnected() {
                runOnUiThread(() -> {
                    tvStatus.setText("已连接");
                    tvStatus.setTextColor(ContextCompat.getColor(MainActivity.this, android.R.color.holo_green_dark));
                    btnConnect.setBackgroundColor(Color.argb(128, 0, 255, 0));
                });
            }

            @Override
            public void onDisconnected() {
                runOnUiThread(() -> {
                    tvStatus.setText("未连接");
                    tvStatus.setTextColor(ContextCompat.getColor(MainActivity.this, android.R.color.holo_red_dark));
                    btnConnect.setBackgroundColor(Color.argb(102, 255, 0, 0));
                });
            }

            @Override
            public void onConnectionFailed(String reason) {
                runOnUiThread(() -> {
                    Toast.makeText(MainActivity.this, "连接失败: " + reason, Toast.LENGTH_SHORT).show();
                    btnConnect.setBackgroundColor(Color.argb(102, 255, 0, 0));
                });
            }

            @Override
            public void onDataReceived(byte[] data) {
                updateFloatingData(data);
            }
        });

        // 横竖屏切换重建 Activity 后，若蓝牙仍处于连接状态，恢复 UI 显示
        if (bluetoothService.isConnected()) {
            tvStatus.setText("已连接");
            tvStatus.setTextColor(ContextCompat.getColor(this, android.R.color.holo_green_dark));
            btnConnect.setBackgroundColor(Color.argb(128, 0, 255, 0));
        }

        checkPermissionsAndEnableBluetooth();
        setupControls();
        setupClickListeners();

        rateUpdater = new Runnable() {
            @Override public void run() {
                bluetoothService.updateRate();
                tvTx.setText("TX: " + bluetoothService.getTotalTxBytes());
                tvRx.setText("RX: " + bluetoothService.getTotalRxBytes());
                tvRate.setText("速率: " + bluetoothService.getCurrentRate() + " B/s");
                mainHandler.postDelayed(this, 1000);
            }
        };
        mainHandler.post(rateUpdater);

        initFloatingWindow();
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putSerializable(KEY_SETTINGS, settings);
        outState.putFloat(KEY_JOY1X, joy1X);
        outState.putFloat(KEY_JOY1Y, joy1Y);
        outState.putFloat(KEY_JOY2X, joy2X);
        outState.putFloat(KEY_JOY2Y, joy2Y);
        outState.putInt(KEY_SEEK, currentSeekValue);
        outState.putBoolean(KEY_BUTTON, buttonPressed);
    }

    // 全屏沉浸：隐藏状态栏与导航栏，去掉顶部标题栏后内容铺满屏幕
    private void applyFullscreen() {
        WindowInsetsControllerCompat controller =
                WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
        controller.hide(WindowInsetsCompat.Type.systemBars());
        controller.setSystemBarsBehavior(
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            applyFullscreen();
        }
    }

    private void initViews() {
        tvStatus = findViewById(R.id.tvConnectionStatus);
        tvTx = findViewById(R.id.tvTxBytes);
        tvRx = findViewById(R.id.tvRxBytes);
        tvRate = findViewById(R.id.tvRate);
        tvJoy1X = findViewById(R.id.tvJoy1X);
        tvJoy1Y = findViewById(R.id.tvJoy1Y);
        tvJoy2X = findViewById(R.id.tvJoy2X);
        tvJoy2Y = findViewById(R.id.tvJoy2Y);
        tvSeekValue = findViewById(R.id.tvSeekValue);
        btnConnect = findViewById(R.id.btnConnect);
        seekBar = findViewById(R.id.seekBar);
        toggleSwitch = findViewById(R.id.toggleSwitch);
        joystick1 = findViewById(R.id.joystick1);
        joystick2 = findViewById(R.id.joystick2);
    }

    private void addOrientationSwitchButton() {
        FrameLayout root = findViewById(android.R.id.content);
        btnOrientationSwitch = new Button(this);
        int size = (int) (50 * getResources().getDisplayMetrics().density);
        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(size, size);
        params.gravity = Gravity.RIGHT | Gravity.BOTTOM;
        params.rightMargin = (int) (16 * getResources().getDisplayMetrics().density);
        params.bottomMargin = (int) (16 * getResources().getDisplayMetrics().density);
        btnOrientationSwitch.setLayoutParams(params);
        btnOrientationSwitch.setBackground(createRoundBackground(Color.argb(102, 100, 100, 100)));
        btnOrientationSwitch.setText("📱");
        btnOrientationSwitch.setTextColor(Color.WHITE);
        btnOrientationSwitch.setTextSize(20);
        btnOrientationSwitch.setOnClickListener(v -> toggleOrientation());
        root.addView(btnOrientationSwitch);
    }

    private void toggleOrientation() {
        if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE) {
            setRequestedOrientation(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        } else {
            setRequestedOrientation(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        }
    }

    private void addRangeModeButton() {
        FrameLayout root = findViewById(android.R.id.content);
        btnRangeModeContainer = new FrameLayout(this);
        int size = (int) (40 * getResources().getDisplayMetrics().density);
        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(size, size);
        params.gravity = Gravity.LEFT | Gravity.BOTTOM;
        params.leftMargin = (int) (16 * getResources().getDisplayMetrics().density);
        params.bottomMargin = (int) (16 * getResources().getDisplayMetrics().density);
        btnRangeModeContainer.setLayoutParams(params);
        btnRangeModeContainer.setBackground(createRoundBackground(Color.argb(102, 255, 0, 0)));
        TextView text = new TextView(this);
        text.setText("范围");
        text.setTextColor(Color.WHITE);
        text.setTextSize(10);
        text.setGravity(Gravity.CENTER);
        btnRangeModeContainer.addView(text, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        btnRangeModeContainer.setClickable(true);
        btnRangeModeContainer.setOnClickListener(v -> toggleSettingMode());
        root.addView(btnRangeModeContainer);
    }

    private GradientDrawable createRoundBackground(int color) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setShape(GradientDrawable.OVAL);
        drawable.setColor(color);
        return drawable;
    }

    private void toggleSettingMode() {
        isSettingMode = !isSettingMode;
        if (isSettingMode) {
            showControlSelectDialog();
        } else {
            Toast.makeText(this, "退出修改模式", Toast.LENGTH_SHORT).show();
            GradientDrawable bg = (GradientDrawable) btnRangeModeContainer.getBackground();
            bg.setColor(Color.argb(102, 255, 0, 0));
        }
    }

    private void showControlSelectDialog() {
        String[] controls = {"摇杆 J1 (X/Y)", "摇杆 J2 (X/Y)", "滑杆"};
        new androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle("选择要修改的控件")
                .setItems(controls, (dialog, which) -> {
                    switch (which) {
                        case 0: showJ1SettingsDialog(); break;
                        case 1: showJ2SettingsDialog(); break;
                        case 2: showSeekBarSettingsDialog(); break;
                    }
                })
                .setNegativeButton("取消", (d, w) -> exitSettingMode())
                .show();
    }

    private void showJ1SettingsDialog() {
        ControlSettingDialog.show(this, "摇杆1 X轴",
                settings.joy1XMin, settings.joy1XMax, settings.joy1XType,
                (minX, maxX, typeX) -> {
                    settings.joy1XMin = minX;
                    settings.joy1XMax = maxX;
                    settings.joy1XType = typeX;
                    ControlSettingDialog.show(this, "摇杆1 Y轴",
                            settings.joy1YMin, settings.joy1YMax, settings.joy1YType,
                            (minY, maxY, typeY) -> {
                                settings.joy1YMin = minY;
                                settings.joy1YMax = maxY;
                                settings.joy1YType = typeY;
                                sendPacketNow();
                                Toast.makeText(this, "J1 参数已更新", Toast.LENGTH_SHORT).show();
                                exitSettingMode();
                            });
                });
    }

    private void showJ2SettingsDialog() {
        ControlSettingDialog.show(this, "摇杆2 X轴",
                settings.joy2XMin, settings.joy2XMax, settings.joy2XType,
                (minX, maxX, typeX) -> {
                    settings.joy2XMin = minX;
                    settings.joy2XMax = maxX;
                    settings.joy2XType = typeX;
                    ControlSettingDialog.show(this, "摇杆2 Y轴",
                            settings.joy2YMin, settings.joy2YMax, settings.joy2YType,
                            (minY, maxY, typeY) -> {
                                settings.joy2YMin = minY;
                                settings.joy2YMax = maxY;
                                settings.joy2YType = typeY;
                                sendPacketNow();
                                Toast.makeText(this, "J2 参数已更新", Toast.LENGTH_SHORT).show();
                                exitSettingMode();
                            });
                });
    }

    private void showSeekBarSettingsDialog() {
        ControlSettingDialog.show(this, "滑杆",
                settings.seekMin, settings.seekMax, settings.seekType,
                (min, max, type) -> {
                    settings.seekMin = min;
                    settings.seekMax = max;
                    settings.seekType = type;
                    seekBar.setMax(max - min);
                    seekBar.setProgress(currentSeekValue - min);
                    sendPacketNow();
                    Toast.makeText(this, "滑杆参数已更新", Toast.LENGTH_SHORT).show();
                    exitSettingMode();
                });
    }

    private void exitSettingMode() {
        isSettingMode = false;
        GradientDrawable bg = (GradientDrawable) btnRangeModeContainer.getBackground();
        bg.setColor(Color.argb(102, 255, 0, 0));
    }

    private void setupControls() {
        seekBar.setMax(settings.seekMax - settings.seekMin);
        seekBar.setProgress(currentSeekValue - settings.seekMin);
        tvSeekValue.setText("当前值: " + currentSeekValue);
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                currentSeekValue = settings.seekMin + progress;
                tvSeekValue.setText("当前值: " + currentSeekValue);
                sendPacketDelayed();
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        toggleSwitch.setOnToggleChangeListener(isOn -> {
            buttonPressed = isOn;
            sendPacketDelayed();
        });

        joystick1.setOnJoystickMoveListener((x, y) -> {
            joy1X = x;
            joy1Y = y;
            tvJoy1X.setText(String.format("J1 X: %.2f", x));
            tvJoy1Y.setText(String.format("J1 Y: %.2f", y));
            sendPacketDelayed();
        });

        joystick2.setOnJoystickMoveListener((x, y) -> {
            joy2X = x;
            joy2Y = y;
            tvJoy2X.setText(String.format("J2 X: %.2f", x));
            tvJoy2Y.setText(String.format("J2 Y: %.2f", y));
            sendPacketDelayed();
        });
    }

    private void setupClickListeners() {
        btnConnect.setOnClickListener(v -> {
            if (bluetoothService.isConnected()) {
                bluetoothService.disconnect();
            } else {
                if (!bluetoothAdapter.isEnabled()) {
                    Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                    startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
                } else {
                    btnConnect.setBackgroundColor(Color.argb(128, 0, 0, 255));
                    Intent intent = new Intent(MainActivity.this, DeviceListActivity.class);
                    startActivityForResult(intent, REQUEST_SELECT_DEVICE);
                }
            }
        });
    }

    private void sendPacketDelayed() {
        long now = System.currentTimeMillis();
        if (now - lastSendTime >= SEND_DELAY_MS) {
            sendPacketNow();
            lastSendTime = now;
        } else {
            mainHandler.removeCallbacks(delayedSend);
            mainHandler.postDelayed(delayedSend, SEND_DELAY_MS);
        }
    }

    private void sendPacketNow() {
        if (!bluetoothService.isConnected()) return;

        int j1y = mapRange(joy1Y, -1f, 1f, settings.joy1YMin, settings.joy1YMax);
        int j1x = mapRange(joy1X, -1f, 1f, settings.joy1XMin, settings.joy1XMax);
        int j2x = mapRange(joy2X, -1f, 1f, settings.joy2XMin, settings.joy2XMax);
        int j2y = mapRange(joy2Y, -1f, 1f, settings.joy2YMin, settings.joy2YMax);
        int seekVal = currentSeekValue;
        int btnVal = buttonPressed ? 1 : 0;

        byte[] j1yBytes = encodeValue(j1y, settings.joy1YType, true, 0, joy1Y);
        byte[] j1xBytes = encodeValue(j1x, settings.joy1XType, true, joy1X, 0);
        byte[] j2xBytes = encodeValue(j2x, settings.joy2XType, true, joy2X, 0);
        byte[] j2yBytes = encodeValue(j2y, settings.joy2YType, true, joy2Y, 0);
        byte[] seekBytes = encodeValue(seekVal, settings.seekType, false, 0, 0);
        byte[] btnBytes = new byte[]{(byte) btnVal};

        int totalLen = 1 + j1yBytes.length + j1xBytes.length + j2xBytes.length + j2yBytes.length + seekBytes.length + btnBytes.length + 1;
        ByteBuffer buffer = ByteBuffer.allocate(totalLen);
        buffer.put((byte) 0xA5);
        buffer.put(j1yBytes);
        buffer.put(j1xBytes);
        buffer.put(j2xBytes);
        buffer.put(j2yBytes);
        buffer.put(seekBytes);
        buffer.put(btnBytes);
        buffer.put((byte) 0x5A);

        bluetoothService.sendData(buffer.array());
    }

    private byte[] encodeValue(int physicalValue, DataType type, boolean isJoystick, float joyRawX, float joyRawY) {
        switch (type) {
            case UINT8: return new byte[]{(byte) (physicalValue & 0xFF)};
            case INT8:  return new byte[]{(byte) physicalValue};
            case UINT16: return ByteBuffer.allocate(2).order(ByteOrder.LITTLE_ENDIAN).putShort((short) physicalValue).array();
            case INT16:  return ByteBuffer.allocate(2).order(ByteOrder.LITTLE_ENDIAN).putShort((short) physicalValue).array();
            case FLOAT32:
                float floatVal = physicalValue;
                if (isJoystick) {
                    if (joyRawX != 0) floatVal = joyRawX;
                    if (joyRawY != 0) floatVal = joyRawY;
                }
                return ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putFloat(floatVal).array();
            default: return new byte[0];
        }
    }

    private int mapRange(float value, float fromLow, float fromHigh, int toLow, int toHigh) {
        return (int) (toLow + (value - fromLow) * (toHigh - toLow) / (fromHigh - fromLow));
    }

    // ---------- 悬浮窗相关 ----------
    private void initFloatingWindow() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!Settings.canDrawOverlays(this)) {
                Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                startActivityForResult(intent, REQUEST_OVERLAY_PERMISSION);
                return;
            }
        }
        createFloatingWindow();
    }

    private void createFloatingWindow() {
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        floatingView = LayoutInflater.from(this).inflate(R.layout.floating_window, null);
        tvFloatingData = floatingView.findViewById(R.id.tv_floating_data);
        btnCollapse = floatingView.findViewById(R.id.btnCollapse);
        btnExpand = floatingView.findViewById(R.id.btnExpand);
        btnFullscreen = floatingView.findViewById(R.id.btnFullscreen);
        floatingTitleBar = floatingView.findViewById(R.id.floatingTitleBar);
        btnExpandFromCollapsed = floatingView.findViewById(R.id.btnExpandFromCollapsed);

        tvFloatingData.setMovementMethod(new ScrollingMovementMethod());

        joyDiameter = (int) (110 * getResources().getDisplayMetrics().density);
        expandedWidth = joyDiameter * 2;
        expandedHeight = joyDiameter;
        collapsedSize = expandedWidth / 5;
        fullscreenWidth = WindowManager.LayoutParams.MATCH_PARENT;
        fullscreenHeight = WindowManager.LayoutParams.MATCH_PARENT;

        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O ?
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY :
                WindowManager.LayoutParams.TYPE_PHONE;
        floatingParams = new WindowManager.LayoutParams(
                expandedWidth, expandedHeight, type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
        );
        floatingParams.gravity = Gravity.TOP | Gravity.START;
        floatingParams.x = 100;
        floatingParams.y = 200;
        originalX = 100;
        originalY = 200;

        windowManager.addView(floatingView, floatingParams);

        // 长按悬浮窗任意区域拖动（展开/收起状态均支持；全屏时禁用拖动）
        FloatingDragLayout dragRoot = (FloatingDragLayout) floatingView;
        dragRoot.setOnDragListener(new FloatingDragLayout.OnDragListener() {
            private int dragBaseX, dragBaseY;

            @Override
            public void onDragStart() {
                dragBaseX = floatingParams.x;
                dragBaseY = floatingParams.y;
            }

            @Override
            public void onDragMove(float dx, float dy) {
                if (currentState == FloatState.FULLSCREEN) return;
                floatingParams.x = dragBaseX + (int) dx;
                floatingParams.y = dragBaseY + (int) dy;
                windowManager.updateViewLayout(floatingView, floatingParams);
            }

            @Override
            public void onDragEnd() {
            }
        });

        // 收起状态的长按拖动（修复瞬移问题）
        btnExpandFromCollapsed.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    // 记录起始位置
                    collapsedDragStartX = event.getRawX();
                    collapsedDragStartY = event.getRawY();
                    collapsedStartPosX = floatingParams.x;
                    collapsedStartPosY = floatingParams.y;
                    isCollapsedDragging = false;
                    hasMovedInCollapsed = false;
                    return true;
                case MotionEvent.ACTION_MOVE:
                    float dx = event.getRawX() - collapsedDragStartX;
                    float dy = event.getRawY() - collapsedDragStartY;
                    if (Math.hypot(dx, dy) > 10) {
                        isCollapsedDragging = true;
                        hasMovedInCollapsed = true;
                        floatingParams.x = collapsedStartPosX + (int) dx;
                        floatingParams.y = collapsedStartPosY + (int) dy;
                        windowManager.updateViewLayout(floatingView, floatingParams);
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                    if (!hasMovedInCollapsed) {
                        // 没有移动，视为点击，展开悬浮窗
                        setFloatState(FloatState.EXPANDED);
                    }
                    isCollapsedDragging = false;
                    hasMovedInCollapsed = false;
                    return true;
            }
            return false;
        });

        // 按钮点击事件
        btnCollapse.setOnClickListener(v -> setFloatState(FloatState.COLLAPSED));
        btnExpand.setOnClickListener(v -> setFloatState(FloatState.EXPANDED));
        btnFullscreen.setOnClickListener(v -> setFloatState(FloatState.FULLSCREEN));
        // 注意：btnExpandFromCollapsed 的点击已包含在长按逻辑中（未移动时视为点击），无需额外设置点击监听以避免重复
        // 但为了清晰，也可以保留点击监听，但会和触摸事件冲突，所以此处不设置。
        // 实际上我们在触摸事件的 ACTION_UP 中已经处理了未移动时的展开。
    }

    private void setFloatState(FloatState newState) {
        if (currentState == newState) return;

        LinearLayout titleBar = floatingView.findViewById(R.id.floatingTitleBar);
        TextView dataArea = floatingView.findViewById(R.id.tv_floating_data);
        Button expandBtn = floatingView.findViewById(R.id.btnExpandFromCollapsed);

        int width, height;
        switch (newState) {
            case COLLAPSED:
                width = collapsedSize;
                height = collapsedSize;
                titleBar.setVisibility(View.GONE);
                dataArea.setVisibility(View.GONE);
                expandBtn.setVisibility(View.VISIBLE);
                break;
            case EXPANDED:
                width = expandedWidth;
                height = expandedHeight;
                titleBar.setVisibility(View.VISIBLE);
                dataArea.setVisibility(View.VISIBLE);
                expandBtn.setVisibility(View.GONE);
                break;
            case FULLSCREEN:
                width = fullscreenWidth;
                height = fullscreenHeight;
                titleBar.setVisibility(View.VISIBLE);
                dataArea.setVisibility(View.VISIBLE);
                expandBtn.setVisibility(View.GONE);
                originalX = floatingParams.x;
                originalY = floatingParams.y;
                floatingParams.x = 0;
                floatingParams.y = 0;
                break;
            default:
                return;
        }
        floatingParams.width = width;
        floatingParams.height = height;
        if (newState == FloatState.FULLSCREEN) {
            floatingParams.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS;
        } else {
            floatingParams.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
        }
        windowManager.updateViewLayout(floatingView, floatingParams);

        if (currentState == FloatState.FULLSCREEN && newState != FloatState.FULLSCREEN) {
            floatingParams.x = originalX;
            floatingParams.y = originalY;
            floatingParams.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
            windowManager.updateViewLayout(floatingView, floatingParams);
        }
        currentState = newState;
    }

    private void updateFloatingData(byte[] data) {
        if (tvFloatingData == null) return;

        String timeStr = timeFormat.format(new Date());
        String content;

        String utf8Text = new String(data, StandardCharsets.UTF_8);
        boolean hasNonPrintable = false;
        for (char c : utf8Text.toCharArray()) {
            if (c < 0x20 && c != '\n' && c != '\r' && c != '\t') {
                hasNonPrintable = true;
                break;
            }
        }
        if (!hasNonPrintable && !utf8Text.trim().isEmpty()) {
            content = utf8Text;
        } else {
            content = bytesToHex(data);
        }

        String messageLine = String.format("[%s] %s", timeStr, content);

        synchronized (receivedMessages) {
            receivedMessages.add(messageLine);
            while (receivedMessages.size() > MAX_MESSAGES) {
                receivedMessages.remove(0);
            }
            StringBuilder displayBuilder = new StringBuilder();
            for (String msg : receivedMessages) {
                displayBuilder.append(msg).append("\n");
            }
            String displayText = displayBuilder.toString().trim();
            runOnUiThread(() -> {
                tvFloatingData.setText(displayText);
                tvFloatingData.post(() -> {
                    if (tvFloatingData.getLayout() != null) {
                        int scrollAmount = tvFloatingData.getLayout().getLineTop(tvFloatingData.getLineCount()) - tvFloatingData.getHeight();
                        if (scrollAmount > 0) tvFloatingData.scrollTo(0, scrollAmount);
                    }
                });
            });
        }
    }

    private String bytesToHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder();
        for (byte b : bytes) {
            sb.append(String.format("%02X ", b));
        }
        return sb.toString().trim();
    }

    // ---------- 权限与生命周期 ----------
    private void checkPermissionsAndEnableBluetooth() {
        String[] permissions;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            permissions = new String[]{Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.ACCESS_FINE_LOCATION};
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            permissions = new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION};
        } else {
            permissions = new String[]{};
        }
        boolean allGranted = true;
        for (String perm : permissions) {
            if (ContextCompat.checkSelfPermission(this, perm) != PackageManager.PERMISSION_GRANTED) {
                allGranted = false;
                break;
            }
        }
        if (!allGranted) {
            ActivityCompat.requestPermissions(this, permissions, PERMISSION_REQUEST_CODE);
        } else {
            if (!bluetoothAdapter.isEnabled()) {
                Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_CODE) {
            for (int result : grantResults) {
                if (result != PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(this, "需要必要权限才能使用蓝牙", Toast.LENGTH_SHORT).show();
                    finish();
                    return;
                }
            }
            if (!bluetoothAdapter.isEnabled()) {
                Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_SELECT_DEVICE && resultCode == RESULT_OK) {
            String address = data.getStringExtra("device_address");
            BluetoothDevice device = bluetoothAdapter.getRemoteDevice(address);
            btnConnect.setBackgroundColor(Color.argb(128, 0, 0, 255));
            bluetoothService.connect(device);
        } else if (requestCode == REQUEST_ENABLE_BT) {
            if (resultCode == RESULT_OK) {
                Toast.makeText(this, "蓝牙已开启", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "需要蓝牙才能工作", Toast.LENGTH_SHORT).show();
                finish();
            }
        } else if (requestCode == REQUEST_OVERLAY_PERMISSION) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (Settings.canDrawOverlays(this)) {
                    createFloatingWindow();
                } else {
                    Toast.makeText(this, "需要悬浮窗权限才能显示接收数据", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // 仅在真正退出（按返回键/主动 finish）时断开蓝牙；
        // 横竖屏切换等配置变更导致的 Activity 重建，不主动断开连接。
        if (!isChangingConfigurations()) {
            bluetoothService.disconnect();
            bluetoothService.setConnectionListener(null);
        }
        mainHandler.removeCallbacks(rateUpdater);
        mainHandler.removeCallbacks(delayedSend);
        if (floatingView != null && windowManager != null) {
            windowManager.removeView(floatingView);
        }
    }
}